# Campaign Architect — Multi-Piece Organic Campaign Arcs

A single post rarely sells on click. A campaign is a STORY told across
pieces, each one moving the audience one step up the awareness ladder and
one step closer to a conversation (WhatsApp/DM by default).

## Step 1 — Awareness map

From Stage 1 intelligence, estimate where the audience actually sits
across Schwartz's 5 levels (rough percentages are fine — "mostly
Problem-Aware with a Solution-Aware minority"). This map decides how many
pieces the arc needs and where it starts. Starting at the wrong level is
the #1 campaign killer.

## Step 2 — Define the arc

An arc is 3-9 pieces. Each piece gets a row in the arc table:

| # | Awareness target | Job of the piece | Emotion planted | Harvested by | Micro-conversion | Doctrine + blend hint | Disruption move |

Before building the table, run the Disruption Engine's trend recon
(`disruption-engine.md`) once for the whole campaign; assign each piece a
disruption move from the Saturation Map, varying moves across the arc —
disrupting the same way every piece stops being disruptive by piece 3.

**Job archetypes by phase:**
- **Espejo (early)**: mirror the audience's internal conversation back at
  them, verbatim register. No offer, no logo dominance. The audience's
  only thought: "esto es exactamente lo que me pasa". (Example: "Publicas,
  publicas, publicas… y aún así nadie te habla.")
- **Reencuadre (early-mid)**: name the REAL problem behind the symptom
  (it's not the content, it's the conversation; it's not the algorithm,
  it's the awareness mismatch). Plants doubt about their current approach.
- **Demostración (mid)**: show, don't claim — a result, a before/after, a
  micro-lesson that delivers real value. Builds "razones para creer".
- **Visualización (mid-late)**: let them see the desired future as already
  happening. (Example: phone screenshot, contact "Cliente potencial":
  "¿cómo te contrato?" — the future state made tangible.)
- **Umbral (late)**: the threshold piece — offer, scarcity if real
  ("faltan 2 semanas"), clear single CTA. Hormozi value equation applied
  HERE and only here: (Dream Outcome × Likelihood) ÷ (Time × Effort).

**The escalation principle**: a piece never sells to a level it hasn't
earned. Early pieces earn attention and trust; only late pieces ask.

## Step 3 — Micro-conversion ladder

Every piece targets ONE micro-conversion, ascending across the arc:
stop-scroll → save → comment (seed the comment with a question or a
keyword prompt) → DM → WhatsApp conversation → show up (event/masterclass)
→ buy. Define for each piece HOW the micro-conversion is asked (caption
CTA, sticker, keyword like "comenta DESPEGA y te mando el link", link in
bio change).

## Step 4 — Rhythm & dependencies

- Posting order is narrative order; note which pieces must land before
  which (Visualización without Espejo first reads as arrogance).
- Suggested cadence per platform norms (feed vs. stories interplay:
  stories re-amplify each feed piece within 24h with a behind-the-scenes
  or poll variant).
- Define the arc's single measurable goal stated by the user (e.g., "N
  WhatsApp conversations before June 27") and which pieces carry the load.

## Step 5 — Deliverable

A compact campaign document containing: awareness map, arc table, per-piece
mini-briefs (each one ready to feed into Ad Forge: piece job + emotion +
headline direction + doctrine/blend hint + micro-conversion), rhythm
calendar, and the teaching note explaining the arc's psychology in plain
language (the user teaches this to students — make the logic visible).

Then offer: "¿Ejecuto la pieza #1?" — running it through Ad Forge stages
3-5 with full tournament.

## Organic vs. paid note

This mode defaults to organic logic (the arc IS the targeting — awareness
levels self-select by engaging). If the user says pauta/Meta Ads, the same
arc becomes a retargeting ladder: cold audiences see Espejo/Reencuadre,
engagers get Demostración/Visualización, warm audiences get Umbral.
