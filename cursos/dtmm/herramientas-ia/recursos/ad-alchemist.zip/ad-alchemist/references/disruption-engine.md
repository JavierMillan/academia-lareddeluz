# Disruption Engine — Live Trend Recon & Contrarian Moves

Disruption is not decoration. It's a calculated bet: occupy the attention
space the category is leaving empty. This engine runs INSIDE Stage 1
(Competitive Field) for every brief, and per-phase in Campaign Architect
arcs.

## Phase 1 — Trend Recon (LIVE, never from memory)

Category trends rot in weeks. Always research the current state before
concepting:

1. **web_search**: "[nicho] marketing tendencias [mes año]", "[categoría]
   anuncios [plataforma]", what hooks/formats creators in this niche are
   pushing right now.
2. **image_search**: pull the actual visual grammar of the category today
   — what do these ads/posts LOOK like this month.
3. **Motion Creative Analytics connector** (if available): real Meta ad
   library data for the brand's competitors — formats, hooks, longevity
   of creatives (long-running ad = it works = it's about to saturate).
4. **User's own intel**: ask nothing extra, but use any
   screenshots/profiles they've shared as primary evidence.

Output — the **Saturation Map** (compact, 5-8 lines):
- **Saturado**: formats/hooks/styles everyone uses (= invisible).
- **Emergente**: rising but not yet everywhere (= surf window open).
- **Muerto**: so abandoned it's almost new again (= revival window).
- **Vacío**: what NOBODY in the category does (= blue ocean).

## Phase 2 — Choose the disruption move

Four moves, pick ONE per piece (state it explicitly):

1. **Surf diferente** — ride an emerging trend but break its one defining
   element (everyone uses the trending audio with talking heads → use it
   over a static Brute Force card). Lowest risk; algorithmic tailwind +
   differentiation.
2. **Inversión total** (Watzlawick / VW "Lemon") — find the category's
   core assumption and do the exact opposite. Everyone shouts benefits →
   open with the flaw. Everyone uses carousels of tips → one image, three
   words. Highest pattern-interrupt; needs a brand with spine.
3. **Vacío azul** — occupy the empty space on the map. No one in the niche
   uses Formato Nativo? No one speaks to the Unaware level? No one uses
   silence/whitespace in a maximalist feed? Claim it before it's a trend.
4. **Resurrección** — revive something from the "Muerto" list with modern
   execution (a 2010s meme format, print-era layout, infomercial tone
   played straight). Nostalgia + surprise; verify the audience's age
   actually remembers it.

Selection logic: match move to brand archetype (Outlaw → Inversión;
Sage → Vacío with Evidencia; Jester → Resurrección; Explorer → Surf) and
to risk tolerance signaled by the user. In campaign arcs, vary the move
across phases — an arc that disrupts the same way 5 times stops being
disruptive by piece 3.

## Phase 3 — Guardrails (disruption ≠ ruido)

Disruption that sacrifices clarity or aesthetics is amateur noise. Every
disruptive concept must still pass:

- **E12 hard gate**: understood in 3 seconds. If the disruption needs
  explaining, it failed.
- **Aesthetic floor**: the chosen style blend (style-palette.md) executes
  at full craft. Disruptive ≠ careless; "different and beautiful" beats
  "different and broken".
- **Tension service test**: the disruption must EXPRESS the narrative
  tension from Stage 2, not distract from it. Shock that doesn't serve
  the story is self-indulgence.
- **E10 antifragility**: does it get stronger when criticized/parodied?
  If a screenshot of it in a hostile group chat makes it MORE interesting,
  ship it. If it dies under scrutiny, kill it.
- **Brand-safety**: cultural sensitivity red flag = instant elimination,
  no appeal (same as tournament hard gates).

## Tournament integration

In Stage 4, disruptive concepts report a **Disruption Differential**: one
line stating which Saturation Map zone they exploit and which move they
use. A concept that lands in "Saturado" territory needs exceptional scores
elsewhere to survive; a concept exploiting "Vacío" with full craft gets
the tiebreak.
