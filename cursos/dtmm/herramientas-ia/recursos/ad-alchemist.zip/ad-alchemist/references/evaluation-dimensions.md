# Evaluation Dimensions — Concept Tournament

Score each surviving concept 1-10 on the relevant dimensions. Use the
weight table to pick which dimensions matter for this brief type.
Don't score all 12 every time — score what's weighted, mention the rest
only if a concept fails one catastrophically.

## The 12 Dimensions

| ID | Dimension | What it measures |
|---|---|---|
| E1 | Attention Capture | Pattern-interrupt strength; scroll-stop probability; first-frame arrest |
| E2 | Awareness Level Alignment | Does it speak at the correct Schwartz level for this segment? |
| E3 | Desire Amplification | Harnesses EXISTING desire vs. trying to manufacture new desire (amplification scores higher) |
| E4 | Identity Resonance | Does the target feel seen as who they ASPIRE to be? |
| E5 | Direct Response Strength | Clear action path, offer clarity, urgency, conversion mechanism (Hormozi Value Equation) |
| E6 | Brand Equity Build | Long-term brand asset contribution vs. short-term response extraction |
| E7 | Cultural Freshness | Months before this approach is saturated; is it fresh or already dying? |
| E8 | Mythological Depth | Surface reference vs. structural resonance with universal stories |
| E9 | Objection Neutralization | % of top customer objections pre-empted inside the ad itself |
| E10 | Antifragility | Stronger or weaker under scrutiny/parody? |
| E11 | Client Approval Probability | "Conference room survival" — will the decision-maker actually approve this? |
| E12 | Reductionist Clarity | One-sentence describable? Visually understood in 3 seconds? |

## Organic dimensions (when distribution is organic)

| ID | Dimension | What it measures |
|---|---|---|
| O1 | Save/Share Worthiness | Would someone save this or send it to a friend? (Utility, identity badge, or "esto me describe") |
| O2 | Conversation Trigger | Does it provoke a comment or DM naturally? Is the comment seeded (question, keyword prompt)? |
| O3 | Arc Fitness | Does it do ITS job in the campaign sequence — plant what the next piece harvests — even if it wouldn't convert standalone? |

For organic briefs: O1-O3 replace E5 as critical alongside E1 + E2. A
piece can "lose" as a standalone ad and still win as the right piece of
the arc — judge it by its assigned job, not by universal conversion.

## Weights by brief type

**Direct Response**: E2 + E5 critical · E1, E3, E9, E12 high · E11 medium
**Brand Building**: E2 + E6 critical · E1, E4, E8, E10, E12 high · E7 medium
**Awareness/Launch**: E1 + E2 critical · E3, E4, E7, E12 high · E10 medium
**High-visibility/risky**: add E10 + E11 as high regardless of type

## Hard gates (instant elimination)

- E2 below 6 → eliminated. Wrong awareness level kills everything else.
- E12 below 6 → eliminated. If it can't be grasped in 3 seconds, it doesn't exist.
- Any cultural-sensitivity or brand-safety red flag → eliminated, no appeal.

## Output format

Compact table: concepts × weighted dimensions, scores, total, winner declared
with a one-line rationale. No essays.
