# Page Converter — Conversion Audit & Rewrite

Turn an existing page, landing, or Instagram profile into an asset that
converts for a stated campaign intent.

## Step 0 — Intent first

Before auditing anything, fix the campaign intent: leads via WhatsApp?
masterclass registrations? sales? follows? An element that's "wrong" for
one intent is right for another. If the user didn't state it, infer from
context and say so.

## Step 1 — Ingest

- **URL**: fetch it with web tools. Read the full page, note structure.
- **Instagram profile**: from screenshot or description, analyze: handle +
  name field (searchable keywords?), bio (awareness level it speaks to,
  hero role, CTA), link strategy, highlights (names + order = a funnel or
  a junk drawer?), pinned posts (do the 3 pins cover Espejo → Demostración
  → Umbral?), grid grammar (visual coherence, style blend detectable?).
- **Screenshot of any page**: read it visually; state what can't be
  assessed (load speed, mobile behavior) rather than guessing.

## Step 2 — Audit (score it like a tournament)

Evaluate against these criteria, each scored 1-10 with one-line evidence:

1. **Awareness match** — what Schwartz level does the page speak to vs.
   the level of the traffic that actually lands there? (Cold organic
   traffic = Problem-Aware at best; a page that opens with services/prices
   is speaking Most-Aware to strangers.)
2. **Hero role** — is the visitor the hero and the brand the mentor
   (StoryBrand), or is the page a monument to the brand?
3. **3-second test** — can a distracted person say what this is, for whom,
   and what to do next?
4. **Internal conversation echo** — does the opening mirror what the
   visitor says to themselves, in their register?
5. **Objection coverage** — are the top 3 objections pre-empted (proof,
   guarantees, process clarity)?
6. **Value equation** (Hormozi) — is the perceived offer above threshold?
   Dream outcome visible? Likelihood backed? Time/effort minimized?
7. **CTA logic** — one dominant action? Does it match the awareness level
   (a cold visitor won't "AGENDA TU SESIÓN", but might "mira esto" or
   "escríbeme la palabra X")? Friction inventory: every field, click, and
   decision between arrival and conversion.
8. **Visual doctrine & blend coherence** — does the aesthetic match the
   brand essence (style-palette.md), or is it template-default?

## Step 3 — Rewrite

Section-by-section (or element-by-element for profiles): **antes →
después → por qué**, with the rationale tied to the criteria above and to
the stated intent. Rewrite copy in the audience's real register. For
profiles, deliver: new bio (with searchable name field), highlight
architecture, 3-pin strategy, link strategy, and grid grammar guidance
(doctrine + blend recommendation).

Include projected scores after changes (honest, not inflated) and mark
the 2-3 changes with the highest conversion leverage as "hacer primero".

## Step 4 — Bridge to other modes

- If the audit reveals the page is fine but traffic arrives at the wrong
  awareness level → recommend a Campaign Architect arc to warm traffic.
- If the rewrite requires new visual assets (hero image, pinned post
  creatives) → offer to execute them via Ad Forge.

## Teaching note

Close with 3-5 lines of "por qué funciona" in plain teaching language —
the psychological principle behind the biggest changes, reusable by the
user with students.
