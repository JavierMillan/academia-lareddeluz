# Doctrina Visual: Proyección Emocional

Una de las doctrinas de la biblioteca (`visual-doctrines.md`). Se activa
SOLO cuando: (a) el usuario la invoca por comando ("usa proyección
emocional", "/proyeccion-emocional"), o (b) la matriz de selección la
elige para este brief. NO es el default universal — cada campaña merece
su propia doctrina. Esta es la voz del dueño de la skill — cuando se
activa, se aplica tal cual.

Antes de crear cualquier anuncio, imagen o concepto visual, NO pienses como
diseñador. Piensa como observador humano.

## Objetivo

Crear imágenes donde el espectador pueda imaginarse viviendo la escena antes
de notar el producto. La prioridad NO es mostrar el producto. La prioridad es
activar una película mental.

## Filosofía

Las personas compran la historia que imaginan. No el producto.

Cada imagen debe responder **"¿Puedo verme ahí?"** antes de responder
**"¿Qué me están vendiendo?"**

## Jerarquía

- 80% emoción
- 10% narrativa
- 10% conversión

## Estilo visual

Fotografía documental. Fotografía observacional. Fotografía de momentos
reales. No publicidad. No fotografía de stock. No estética corporativa.
No estética IA.

La imagen debe sentirse como: una fotografía tomada por una persona real ·
un recuerdo · un instante auténtico · una escena encontrada.

NO: una sesión de fotos · una campaña publicitaria evidente · una escena
perfectamente producida · una imagen hiper cinematográfica.

## Composición

Principios reales de fotografía: regla de tercios · profundidad natural ·
encuadres imperfectamente perfectos · elementos parcialmente cortados ·
sujetos fuera del centro · luz natural.

Permitir: pequeñas imperfecciones · desenfoques naturales · momentos
espontáneos.

## Evitar

HDR agresivo · colores exagerados · iluminación artificial evidente ·
fondos futuristas · poses mirando a cámara · sonrisas forzadas · branding
dominante · producto ocupando el centro de la escena.

## Producto

El producto es un actor secundario. Nunca el protagonista. Integrado de
forma orgánica — como algo que naturalmente estaría allí.

## Emoción

Buscar: rituales · momentos cotidianos · hábitos · identidad · nostalgia ·
pertenencia · satisfacción silenciosa.

No buscar: felicidad exagerada · celebración artificial · entusiasmo
publicitario.

## Método de creación

1. Identifica qué quiere SENTIR el cliente.
2. Encuentra un momento real donde esa emoción exista.
3. Integra el producto dentro de ese momento.
4. Agrega solo el texto indispensable.
5. Valida: **¿La imagen sigue funcionando si elimino el producto?**
   Si NO → rehacer. Si SÍ → continuar.

## Influencia Hormozi

Después de construir la emoción: agregar valor percibido, razones para
creer, diferenciación, oferta — sin romper la inmersión emocional.

**La historia abre. La oferta cierra.**

## Filtro final

No crear anuncios. Crear recuerdos que casualmente contienen una marca.
No crear compradores. Crear personas que se imaginan viviendo una
experiencia.

Si parece publicidad → volver a empezar.
Si parece un momento real donde existe un producto → continuar.

---

# Operationalización (cómo la skill ejecuta esta doctrina)

## El Photo Prompt Package

Cuando un concepto fotográfico gana el torneo, construye SIEMPRE este
paquete (sirve tanto para motores conectados como para que el usuario lo
ejecute en su herramienta de imágenes preferida):

1. **Escena** (2-3 frases): el momento documental exacto. Quién, dónde,
   qué está pasando, qué pasó un segundo antes. Tiempo y lugar concretos
   ("domingo 7:40am, cocina con luz de ventana", no "ambiente acogedor").
2. **Emoción somática**: la emoción dominante del Stage 2, nombrada.
3. **Dirección de cámara**: encuadre, distancia, qué queda parcialmente
   cortado, dónde está el sujeto (fuera de centro), tipo de luz natural,
   imperfección permitida (grano, leve desenfoque, reflejo).
4. **Ubicación del producto**: dónde vive en la escena como actor
   secundario.
5. **Negativos explícitos**: la lista de "Evitar" de arriba, adaptada a la
   escena (siempre incluir: no studio lighting, no stock photo look, no
   AI aesthetic, no posing at camera).
6. **Validación**: confirmar por escrito que la escena pasa el filtro
   "¿funciona sin el producto?".

## Capa de texto

El texto NUNCA va "horneado" en la imagen generada. La tipografía se
renderiza por código encima (ver visual-render.md), con el mínimo
indispensable: la historia abre (imagen), la oferta cierra (texto).
Texto pequeño, quieto, que no rompa la inmersión — la jerarquía 80/10/10
gobierna el peso visual del copy.

## Test de cierre

Antes de entregar, el render final (imagen + texto) debe pasar:
- ¿Un humano scrolleando sentiría que es un momento, no un anuncio?
- ¿El ojo llega a la emoción antes que al producto y al texto?
- ¿El copy cierra una intención (guardar, comentar, escribir por WhatsApp)
  sin gritar?
