# Style Palette — Aesthetic DNA & Blend System

The doctrine (visual-doctrines.md) defines WHAT the image is conceptually.
The style blend defines HOW it looks — its aesthetic DNA. Like interior
design: a brand can be "60% nórdico / 30% japandi / 10% industrial".

## The blend system

Every execution declares a blend:
- **Dominant style: 50-70%** — governs layout logic, primary typography,
  and overall temperature.
- **Secondary style: 20-40%** — governs accents, secondary type, texture
  or color behavior.
- **Accent style: ≤10% (optional)** — one deliberate detail only (a
  texture, a single ornament, a color hit). More than one detail and it
  stops being an accent.

Rules:
1. Maximum 3 styles per blend. Two is often stronger than three.
2. The blend is derived from the BRAND's essence (Stage 1: archetype,
   audience, category), never from operator preference. Two clients must
   not receive the same blend by coincidence — check the anti-uniformity
   ledger.
3. Declare the blend explicitly in Stage 3 output, with one line of
   rationale, e.g.: "Blend: 60% neobrutalismo refinado / 30% art déco /
   10% retrofuturismo — la marca tiene voz confrontativa (brutalismo)
   pero vende un servicio premium con herencia (déco)."
4. The percentages are real instructions for the render: dominant decides
   grid + headline font + palette base; secondary decides support font +
   one compositional behavior; accent appears exactly once.
5. Respect the incompatibility notes below; some DNAs reject each other.

## The styles

### Timeless foundations

**Suizo / Internacional** — Grid estricto, sans grotesca (Helvetica/Inter),
jerarquía matemática, mucho blanco. Transmite: orden, competencia,
neutralidad confiable. Para: B2B, consultoría, tecnología seria.

**Bauhaus / Geométrico** — Formas primarias (círculo, triángulo, barra),
rojo/amarillo/azul + negro, asimetría funcional. Transmite: modernidad
optimista, claridad con carácter. Para: educación, productos funcionales.

**Minimalismo premium** — Un elemento, océano de espacio negativo, serif
display o grotesca light, paleta muda (2026: "Digital Minimalism 2.0" —
cada elemento con función clara, cero decoración). Transmite: confianza
silenciosa, lujo. Para: high-ticket, marca personal madura.

**Art Déco** — Simetría, geometría ornamental, dorados/negros/jewel tones,
serif con personalidad o sans geométrica alta. Transmite: glamour, herencia,
aspiración. Para: premium con historia, eventos, hospitalidad.

**Editorial / Revista** — Columnas, pull-quotes, foto + pie de foto,
serif de texto + sans de apoyo, ritmo de lectura. Transmite: autoridad
periodística, sustancia. Para: thought leadership, evidencia, B2B.

**Retro 70s-90s / Y2K** — Paletas cálidas quemadas o cromos y degradados
plásticos, tipografía con nostalgia específica de década. Transmite:
pertenencia generacional, calidez o ironía. Para: audiencias que vivieron
(o fetichizan) esa década.

**Hecho a mano / Zine / Collage** — Recortes, cinta, subrayados de
marcador, texturas de fotocopia. Transmite: autenticidad DIY,
anti-corporativo, cercanía. Para: comunidades, creadores, causas.

**Orgánico natural** — Formas orgánicas, paletas terrosas mudas, texturas
táctiles, sin simbolismo gritado. Transmite: honestidad, equilibrio,
bienestar. Para: salud, alimentación consciente, sostenibilidad.

### Vigentes 2026 (investigado, no inventado)

**Neobrutalismo refinado** — Evolución estructurada del brutalismo:
elementos firmes, alto contraste, layout no convencional pero controlado.
Transmite: confrontación con confianza. Para: marcas con posicionamiento
audaz, llamadas Problem-Aware.

**Brute Force** — El hermano maduro del brutalismo: tipografía pesada
apilada, grids tipo hoja de cálculo, composición deadpan, blanco/negro con
golpes escasos de color. Transmite: honestidad sin pretensión, "la verdad
sin filtro". Para: editorial, instituciones, premium que no necesita
decorar.

**Maximalismo intencional** — Densidad por capas: tipografía, color,
imagen y textura sobrepuestos, exceso con estructura subyacente. PELIGRO
2026: hay fatiga del maximalismo mal hecho e ilegible — solo usar con
ejecución deliberada. Transmite: personalidad, energía, individualidad.
Para: música, moda, Gen Z, lanzamientos ruidosos.

**Retrofuturismo** — Nostalgia sci-fi + tecnología moderna: cromos,
neones mudos de diner sesentero, texturas metálicas con calidez análoga
(grano de película, semitonos de imprenta para mantener lo táctil).
Transmite: visión con raíces. Para: tecnología con alma, innovación.

**Type Collage** — Tipografía como collage: estilos mezclados, jerarquías
rotas a propósito, eco de zines y web temprana. Transmite: frescura DIY
que la Gen Z lee como auténtica. Para: comunidad joven, contracultura.

**Blueprint / Técnico** — Lenguaje de planos y sistemas: líneas de
anotación, marcadores técnicos, lógica visible, estética de dato y
proceso. Transmite: oficio, lógica, precisión. Para: tech, arquitectura,
marcas data-driven, demostrar método (¡ideal para enseñar marketing!).

**Gradientes emocionales** — Degradados suaves como herramienta de ánimo:
transiciones cromáticas que crean continuidad emocional, no contraste
duro. Transmite: calma, transformación, fluidez. Para: bienestar,
desarrollo personal, apps.

**Blur y distorsión intencional** — Bordes esfumados, ruido visual, foco
suave priorizando atmósfera sobre precisión. Transmite: emoción, memoria,
ambigüedad poética. Para: marca personal íntima, storytelling emocional.

## Incompatibilities & friction pairs

- Minimalismo premium + Maximalismo: contradicción directa; nunca en un
  mismo blend.
- Suizo dominante + Type Collage secundario: fricción productiva SOLO si
  el collage vive en una zona delimitada del grid.
- Brute Force + Gradientes emocionales: se anulan; elegir bando.
- Art Déco + Blueprint: rara, pero puede funcionar como "ingeniería de
  lujo" — usar con plena intención.
- Cualquier estilo nostálgico (Retro, Déco, Retrofuturismo) exige
  especificidad de década/referente; la nostalgia genérica lee falsa.

## Mapping brand essence → blend (quick heuristics)

- Voz confrontativa + servicio serio → Neobrutalismo dominante / Suizo o
  Déco secundario.
- Mentor cálido + transformación personal → Gradientes emocionales u
  Orgánico dominante / Editorial secundario.
- Experto que enseña con método → Blueprint dominante / Suizo secundario.
- Marca joven de comunidad → Type Collage o Zine dominante / Retro
  secundario.
- Premium silencioso → Minimalismo dominante / Brute Force o Déco
  secundario (según temperatura).

These are starting points, not rules — the matrix in visual-doctrines.md
and the Stage 1 intelligence always have the final word.
