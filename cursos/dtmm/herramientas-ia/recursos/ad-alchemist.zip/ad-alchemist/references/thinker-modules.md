# Thinker Modules — Expert Board

Functional cognitive lenses for the Expert Board Debate (Stage 3) and
Tournament voting (Stage 4). Each thinker asks ONE ruthless question of
every concept. Use the activation column to pick who debates per brief type.

## Always Active (every brief)

| Thinker | Role | The question they ask |
|---|---|---|
| Eugene Schwartz | Awareness Architecture | Is this speaking at the audience's actual awareness level? Is it amplifying existing desire or trying to manufacture new desire? (Amplify > manufacture, always.) |
| Bill Bernbach | Human Truth Auditor | Is this grounded in a genuine human truth, or merely clever? Reject sophistication that obscures rather than reveals. |
| Daniel Kahneman | Dual-Process Auditor | Is this targeting System 1 (fast, intuitive) or System 2 (deliberate)? Is that the right system for this product and decision? |
| Rory Sutherland | Psycho-Logic | Is there an irrational solution that works better than the rational one? Can changing perception beat changing reality? |
| Antonio Damasio | Somatic Marker | What does this ad make the body FEEL? Emotion is the mechanism of decision, not its enemy. No feeling = no decision. |
| Dieter Rams | Reductionist Clarity | What can be removed? Every element not serving the singular purpose dies. Complexity is the enemy of memorability. |
| Claude Hopkins | Scientific Testing | Is every claim verifiable? Is there a measurable response mechanism? Creativity without accountability is decoration. |

## Direct Response briefs (add these, weight highest)

| Thinker | Role | The question |
|---|---|---|
| Alex Hormozi | Value Equation | (Dream Outcome × Perceived Likelihood) ÷ (Time Delay × Effort) — does the offer score above threshold? |
| Dan Kennedy | Ruthless Conversion | Will someone reach for their wallet TODAY? No mercy for clever concepts that don't convert. |
| Robert Cialdini | Influence Levers | Which levers are active (reciprocity, commitment, social proof, authority, liking, scarcity, unity)? Which obvious one is missing? |
| Richard Thaler | Choice Architecture | How are options framed, anchored, ordered? Same product, different frame = double or half the conversion. |
| Chris Voss | Objection Specialist | Does the customer feel HEARD before being sold to? Tactical empathy in the copy; calibrated questions that disarm. |

## Brand Building / Awareness briefs (add these, weight highest)

| Thinker | Role | The question |
|---|---|---|
| David Ogilvy | Brand Longevity | Will this still be building the brand's reputation in 20 years, or is it burning equity for short-term response? |
| Carl Jung | Archetype & Shadow | Which archetype does this activate (Hero, Shadow, Trickster, Sage...)? Does it touch the shadow motivations people won't admit? |
| Joseph Campbell | Mythological Structure | Is the customer the hero and the brand the mentor? Does buying feel like crossing a threshold? |
| Donald Miller | StoryBrand Clarity | Is the customer the hero — not the brand? Can a distracted person grasp the story instantly? |
| Viktor Frankl | Meaning Architecture | Does this sell a product, or a reason to live differently? (For premium/purpose briefs.) |
| George Lois | Provocation | What would make the entire industry stop and notice? Push toward the most culturally explosive version. |
| Edward Bernays | Mass Psychology | Does this engineer the social environment in which individuals decide? Social proof, opinion leaders, movement logic. |

## Situational

| Thinker | Activate when | The question |
|---|---|---|
| Sun Tzu | Competitive positioning brief | Where will competitors move next? What ground can they NOT defend? Attack there. |
| Marshall McLuhan | Always at execution stage | Is this NATIVE to the medium, or adapted to it? A TikTok concept is not a TV concept reformatted. |
| Roland Barthes | Visual/copy execution | What does every element mean denotatively (literal) AND connotatively (cultural)? Both must be engineered, neither accidental. |
| Claude Lévi-Strauss | Brand positioning | Which binary opposition organizes this category (pure/contaminated, us/them, wild/civilized)? Is the brand on the mythologically correct side? |
| Edward de Bono | Concepts converging / feel samey | Apply lateral tools: random entry, provocation, concept fan. Escape the convergence. |
| Nassim Taleb | High-visibility campaign | Does this get STRONGER when attacked or parodied, or does it die under scrutiny? Fragile campaigns don't ship. |
| Paul Watzlawick | Skeptical/high-resistance audience | Where is the expected approach exactly wrong? Engineer the counterintuitive reframe (VW "Lemon" logic). |

## Debate protocol

For each concept, pick the 4-6 most relevant thinkers. Each gives 1-2 lines:
the strongest attack OR the strongest defense. Concepts that survive the
hardest attacks advance to the Tournament. Keep it punchy — this is a knife
fight, not a seminar.
