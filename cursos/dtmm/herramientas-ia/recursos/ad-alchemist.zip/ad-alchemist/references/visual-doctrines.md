# Visual Doctrines — Style Library & Selection Matrix

A "doctrine" is a complete visual philosophy: what the image is, how it's
composed, what it must never look like. Every winning concept executes
under exactly ONE doctrine.

## The cardinal rule: no house style

This skill serves an agency. Two different clients must never receive the
same doctrine by default. The doctrine is derived from THE BRAND'S essence
(archetype, audience, category grammar) — never from the operator's
personal taste, never from what worked last time.

**Anti-uniformity ledger**: within a conversation, track which doctrines
have been used per client/brand. Consecutive campaigns for different
brands must not share a doctrine unless the selection matrix independently
lands there AND you state why. When concepts are generated in Stage 3,
they should deliberately span 2-3 different doctrines so the tournament
chooses between genuinely different worlds, not variations of one.

## Command interface

The user can force a doctrine at any time by naming it ("usa proyección
emocional", "modo provocación", "hazlo formato nativo"). A forced doctrine
skips the matrix but still passes the tournament's hard gates.

## The doctrines

### 1. Proyección Emocional (documentary photography)
The viewer imagines living the scene before noticing the product.
80% emotion / 10% narrative / 10% conversion. Full doctrine — read
`proyeccion-emocional.md` when activated; it is detailed and mandatory
once selected.
**Best for**: lifestyle, rituals, belonging, identity products; Lover /
Everyman / Caregiver archetypes; Unaware → Problem-Aware audiences;
brand building. **Engine**: photographic (or Photo Prompt Package).

### 2. Tipografía Brutal (type-led graphic)
The headline IS the image. Massive scale contrast, 2 colors + neutral,
the internal conversation of the customer printed at 10-15% of canvas
height. Pattern interrupt by typographic violence and whitespace.
**Best for**: Problem-Aware callouts ("publicas, publicas, publicas…"),
direct response, Outlaw / Hero archetypes, crowded photographic feeds
(disruption by NOT being a photo). **Engine**: code render (native
strength — no image engine needed).

### 3. Formato Nativo (platform mimicry)
The ad disguises itself as the platform's own content: a WhatsApp/iMessage
screenshot, a Notes-app confession, a calendar reminder, a bank
notification. The viewer processes it as life, not advertising, for the
first 2 seconds — that's the hook. (Example: phone screen showing a
contact named "Cliente potencial" texting "¿cómo te contrato?".)
**Best for**: Solution/Product-Aware audiences, urgency beats
("faltan 2 semanas"), McLuhan-native organic content, DM/WhatsApp
conversion goals. **Engine**: code render (UI is geometry + type).
**Ethical gate**: mimicry must be evidently playful on second glance —
never deceive about who is speaking or fabricate real people's messages.

### 4. Minimalismo Premium (editorial restraint)
One element, oceanic whitespace, serif display or light grotesque,
muted palette. Confidence communicated by what's absent. Price/offer
whispered, never shouted.
**Best for**: high-ticket services, Ruler / Sage archetypes, Most-Aware
audiences, premium positioning where the category screams discounts.
**Engine**: code render or photographic (single object, natural light).

### 5. Provocación Cultural (George Lois)
The image the industry can't ignore: cultural symbol subverted, taboo
boundary touched (never crossed into harm), binary opposition flipped.
Designed to be screenshotted and argued about.
**Best for**: launches needing earned attention, Outlaw / Jester
archetypes, high-visibility plays. Must pass E10 (antifragility) and
E11 (approval probability) — this doctrine dies in scrutiny-weak hands.
**Engine**: either.

### 6. Evidencia Editorial (proof-driven)
The ad is an exhibit: before/after, annotated screenshot of real results,
data made beautiful, testimonial typeset like a pull-quote. Hopkins logic:
every claim verifiable.
**Best for**: skeptical/high-resistance audiences, Solution-Aware →
Product-Aware transitions, B2B and service businesses, retargeting beats
in a campaign arc. **Engine**: code render.

## Selection matrix

Score each doctrine 1-5 against the brief on these four axes, pick the
highest total; break ties toward category disruption:

1. **Archetype fit** — does the doctrine speak the brand archetype's
   native language?
2. **Awareness fit** — does it match where THIS piece's audience sits?
   (In campaign arcs, different pieces of the same arc may use different
   doctrines — early pieces often Brutal/Proyección, late pieces often
   Nativo/Evidencia.)
3. **Category disruption** — Stage 1 mapped the competitors' grammar;
   does this doctrine violate it?
4. **Conversion mechanics** — does the doctrine naturally carry this
   brief's micro-conversion (save, comment, DM, click)?

State the chosen doctrine and one-line rationale in the Stage 3 output.
The user can always override.
