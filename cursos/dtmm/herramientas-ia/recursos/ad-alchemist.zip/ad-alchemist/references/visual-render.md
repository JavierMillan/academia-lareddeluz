# Visual Render — Ad Execution Engine

How to turn the winning concept into a real deliverable. The output must
look like a senior art director labored over it — not like generated filler.

## Engine detection (run first)

The winning concept's doctrine (visual-doctrines.md) determines the
required engine:

**Graphic doctrines** (Tipografía Brutal, Formato Nativo, Minimalismo
Premium graphic, Evidencia Editorial) → **code render** (below). Native
strength, always available.

**Photographic doctrines** (Proyección Emocional, photographic Minimalismo
or Provocación) → need an image engine. Check in order:
1. **Adobe for creativity connector** (Firefly) — if connected, generate
   the photographic layer there using the Photo Prompt Package from
   `proyeccion-emocional.md` (its structure works for any photographic
   doctrine), then composite the typographic layer via code on top.
2. **Image generation API via bash** — only if the user has added the
   relevant API domain to their network allowlist and provided a key;
   otherwise skip (default sandbox can't reach fal.ai/Ideogram/etc.).
3. **No engine available** → degrade gracefully: deliver (a) the complete
   Photo Prompt Package as copy-ready text for the user's preferred image
   tool, and (b) the typographic overlay rendered by code as a separate
   transparent-background PNG, with compositing instructions (position,
   size %). Never fake photography with gradients (rule 8).

Text is NEVER baked into generated photographic images — typography is
always the code-rendered layer on top.

## Code render technique

Render via **SVG composed by hand, converted to PNG**. This gives precise
typographic control, perfect geometry, and gradients/shapes that read as
deliberate design.

```bash
pip install cairosvg --break-system-packages --quiet
```

```python
import cairosvg
cairosvg.svg2png(url="ad.svg", write_to="/mnt/user-data/outputs/ad_final.png",
                 output_width=W, output_height=H)
```

If cairosvg fails (rare), fall back to Pillow (PIL) drawing directly.
Alternative for texture-heavy designs: Pillow + numpy for noise/grain layers
composited over the SVG render.

## Canvas dimensions by medium

| Medium | Pixels |
|---|---|
| Instagram post (default) | 1080 × 1350 |
| Story / Reel cover | 1080 × 1920 |
| Square | 1080 × 1080 |
| Facebook / landscape | 1200 × 628 |
| Print poster A4 @300dpi | 2480 × 3508 |

## Fonts

Never use default serif/sans fallbacks — they scream "generated". Download
real fonts at render time (Google Fonts via GitHub raw is in the allowed
network domains):

```bash
mkdir -p /home/claude/fonts && cd /home/claude/fonts
wget -q https://github.com/google/fonts/raw/main/ofl/archivoblack/ArchivoBlack-Regular.ttf
wget -q https://github.com/google/fonts/raw/main/ofl/inter/Inter%5Bopsz%2Cwght%5D.ttf
```

Good pairings for ads: Archivo Black / Anton / Bebas Neue (display) with
Inter / Work Sans (support). For premium briefs: Playfair Display or
Cormorant (display) with a light grotesque. Register fonts in the SVG with
`@font-face` pointing at the local file path, or convert text to paths if
rendering issues appear.

## Design rules (non-negotiable)

1. **The concept drives the layout.** The visual must EXPRESS the winning
   concept's tension — not decorate it. Ask: if someone saw only the image
   with no explanation, would they feel the narrative tension?
2. **3-second test (E12).** One dominant focal point. One headline. Visual
   hierarchy so strong the eye path is involuntary: hook → tension → resolution/CTA.
3. **The style blend governs the aesthetic.** Execute the declared blend
   from style-palette.md literally: dominant style (50-70%) decides grid,
   headline font, and palette base; secondary (20-40%) decides support
   font and one compositional behavior; accent (≤10%) appears exactly
   once. Limited palette always: 2-3 colors + one neutral, derived from
   brand identity or the somatic anchor. Never rainbow.
4. **Typography as the protagonist** when there's no photography. Massive
   scale contrast: headline can be 8-15% of canvas height; support text
   small and quiet. Scale contrast = perceived craft.
5. **Whitespace is a power move.** Crowded = amateur. At least 8% margin on
   all sides; nothing touches edges unless deliberately bleeding (full-bleed
   color blocks are fine, text never bleeds).
6. **Nothing overlaps accidentally. Nothing falls off canvas.** Verify by
   rendering and VIEWING the PNG before delivering (use the view tool on the
   output file). If anything collides, clips, or misaligns — fix and re-render.
   Minimum one inspection pass, always.
7. **Disrupt the category grammar.** Stage 1 mapped what competitor ads look
   like. The render should violate at least one category convention
   deliberately (the Aesthetic Disruption move).
8. **No fake photos.** Don't simulate photography with gradients. Work in the
   language of graphic design: geometry, type, color fields, patterns,
   iconographic illustration built from primitives. A confident graphic ad
   beats a fake photographic one every time.
9. **CTA present but proportionate**: prominent for DR briefs (button-like
   shape or high-contrast line), whisper-quiet or absent for pure brand briefs.
10. **Logo/brand mark**: small, anchored to a corner or bottom strip unless
    the brief is brand-launch (then it can be the hero).

## Craft pass (mandatory)

After the first render, view the PNG and run a second pass asking only:
"How do I make what's already here more refined?" — kerning, optical
alignment, color balance, spacing rhythm. Do NOT add new elements in the
craft pass. Refine, never decorate.

## Delivery

- Save final to `/mnt/user-data/outputs/` with a descriptive name
  (`ad_[brand]_[concept]_1080x1350.png`).
- Present via present_files.
- Keep the SVG source in /home/claude in case the user requests tweaks —
  offer to adjust copy/colors without rebuilding strategy.
