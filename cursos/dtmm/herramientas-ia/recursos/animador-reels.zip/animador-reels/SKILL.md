---
name: animador-reels
description: 'Anima tu guion como video de motion graphics: una cámara que viaja por el mundo de tu marca, no diapositivas. Úsalo para reels, stories y anuncios en video. Va después de Prism y Ad Alchemist.'
---

# Animador de reels — cámara, no diapositivas

Versión para alumnos de *De tu mente al mundo*. Es la tercera de tres skills
que trabajan en cadena:

| Orden | Skill | Qué resuelve |
|---|---|---|
| 1 | **Prism** | Cómo se ve tu marca: colores, letras, estilo, códigos |
| 2 | **Ad Alchemist** | Qué decir: la idea, el gancho y el guion |
| 3 | **Animador de reels** (esta) | Cómo se mueve: el mundo, la cámara y el render |

Si ya existe el perfil de marca de Prism o el guion de Ad Alchemist en la
conversación o en el proyecto, úsalos tal cual: no los reinventes. Si no
existen, pide los datos que falten antes de animar.

## Cómo trabajar (en este orden, siempre)

1. **Datos.** Marca, qué vende, para quién, dónde se publica, formato
   (1080×1080 o 1080×1920), duración, qué quiere que haga quien lo ve,
   colores, tipografías y lo que nunca se usa. Si faltan, pregúntalos todos
   juntos.
2. **Guion con "pero" y "por eso".** Las frases tal cual saldrán en pantalla:
   gancho → problema → pero (el giro) → freno (el silencio) → por eso / remate.
   Lee cada unión: si alguna es "y luego", reescríbela. Si el usuario no trae
   guion, escríbelo tú y **espera su aprobación** antes de seguir.
3. **El mundo.** Propón dónde ocurre, sacado del ADN de la marca (un plano
   técnico, un pliego de revista, un gráfico navegable…). Nunca "fondo
   oscuro con partículas". **Espera su visto bueno.**
4. **Cuadros clave.** Antes del render completo, enseña 4–6 cuadros de los
   momentos importantes para revisar encuadres y legibilidad.
5. **Render completo** y verificación (tira de contacto, tira a 180 px,
   curva de movimiento con un solo valle, audio, duración, `yuv420p`).
6. **Correcciones.** Cuando el usuario diga que algo está mal, créele antes
   que a tus números y pregúntale qué debería pasar en vez de adivinar.

Lo que sigue es el método completo y las reglas técnicas.

| Archivo | Para quién |
|---|---|
| `references/master-prompt.md` | Un prompt listo para copiar y pegar |
| `references/guia-desde-cero.md` | Alguien sin conocimientos técnicos |
| `references/pipeline.md` | El recorrido completo, paso a paso |
| `assets/` | Escena de ejemplo y los tres scripts |

La diferencia entre un video de motion graphics y una presentación animada no es
la cantidad de animación: es si existe un **espacio**. En una diapositiva los
elementos entran y salen del mismo plano. En motion graphics hay un mundo, y una
cámara que se mueve dentro de él.

**La prueba:** si puedes reordenar las escenas sin que nada se rompa, son
diapositivas. Si moverlas rompe la geografía, es espacial.

## El principio: el contenido ya está ahí

Esta es la inversión mental que hace todo lo demás.

| Diapositiva | Espacial |
|---|---|
| El texto **aparece** (opacidad 0→1) | El texto **ya existe**; la cámara llega a él |
| Corte entre escenas | Un solo movimiento continuo |
| El fondo es un telón | El fondo es el suelo del mundo |
| La oferta entra al final | La oferta **siempre estuvo** en su lugar del mundo |

Cuando el contenido preexiste, el movimiento *significa* algo: acercarse es
intimidad, alejarse es contexto, detenerse es tensión.

## Método

### 1. Define el mundo antes que las escenas
Pregunta: **¿dónde ocurre esto?** El espacio debe salir del ADN visual de la
marca, no ser un fondo genérico.

- Una marca de ingeniería → un plano técnico con cotas y cajetín.
- Una marca editorial → un pliego de revista, columnas que se recorren.
- Una marca de datos → un gráfico gigante por el que se navega.
- Una marca de código → un archivo que hace scroll infinito.

Si el espacio es "un fondo oscuro con partículas", vuelve a empezar: eso es
telón.

### 2. Coloca el contenido como geografía
Escribe las frases del guion **en coordenadas del mundo**, no en orden de
aparición. Deben tener sentido espacial entre sí: lo que se dice al principio
está cerca; lo que revela contexto está lejos; el remate está en el lugar que
narrativamente le toca (el cajetín de un plano, el pie de una página).

### 3. Diseña la trayectoria de cámara
Una lista de keyframes `[t, x, y, z, rotX, rotZ]`. Reglas:

- **Un solo sentido dominante.** Ir y volver marea y se lee como indecisión.
- **El zoom-out revela, el zoom-in confronta.** Elige según lo que dice el guion.
- **El freno es un recurso narrativo.** Detener la cámara 1–2s donde el guion
  tiene un silencio pega más fuerte que cualquier efecto — pero solo si es la
  ÚNICA pausa (ver abajo).
- **La rotación en dosis mínimas** (2–10°). Más que eso se siente videojuego.
- Easing sin rebote para marcas técnicas: `cubic-bezier(.45,0,.22,1)`.

#### El error del acordeón (el más caro de todos)

**Nunca apliques easing tramo por tramo.** Si cada par de keyframes arranca en
cero y frena en cero, la cámara patina: cinco acelerones con cuatro valles
muertos. El ojo lo lee como un motor fallando, y el freno narrativo deja de
notarse porque todo frena.

El easing vive en la **línea de tiempo global** (un arranque al principio, un
asentamiento al final) y la interpolación entre keyframes es **Catmull-Rom**,
que conserva velocidad continua al cruzar cada punto.

```js
function catmull(p0, p1, p2, p3, s) {
  const s2=s*s, s3=s2*s;
  return 0.5*((2*p1) + (-p0+p2)*s + (2*p0-5*p1+4*p2-p3)*s2 + (-p0+3*p1-3*p2+p3)*s3);
}
```

Para que el freno exista, pon dos keyframes casi idénticos en ese momento; la
curva se aplana sola. Verifícalo midiendo (abajo): debe haber **un solo valle**.

#### Encuadre: calcula, no adivines
La escala aparente es `perspective / (perspective - z)`. Con `perspective:1400`
y texto de 74px:

| z | escala | se ve a |
|---|---|---|
| 1150 | 5.6x | 414px (textura, ilegible — correcto para abrir) |
| 980 | 3.3x | 247px (se sale del encuadre de 1080) |
| 120 | 1.09x | 81px (legible y completo) |

Si el texto clave nunca baja de ~110px aparentes, está cortado todo el video.
Un zoom que solo recorre de 3.3x a 1.8x no se lee como viaje: busca un rango
de al menos 3x entre inicio y fin.

### 4. Revelación por encuadre, no por opacidad
El texto nunca va de 0 a 1. Va de **0.08 a 1**: siempre está presente, solo gana
legibilidad cuando la cámara lo encuadra. Esa base de 0.08 es lo que hace que el
ojo perciba un mundo continuo en vez de apariciones.

```js
el.style.opacity = 0.08 + 0.92 * ease(prog(t, inicio, duracion));
```

### 5. Capas con propósito
- **Mundo (3D):** todo lo que vive en el espacio y respeta la perspectiva.
- **HUD (2D):** lo poco que va pegado a la cámara — badge, coordenadas, marco.
  Máximo 2 elementos; si todo es HUD, volviste a las diapositivas.
- **Viñeta:** oscurecer los bordes da profundidad óptica real. No es decoración.

## Implementación

Estructura mínima: `#viewport` tiene la `perspective`; `#world` es el espacio;
mover `#world` al revés **es** mover la cámara.

```html
<div id="viewport" style="perspective:1400px">
  <div id="world" style="transform-style:preserve-3d">
    <!-- todo el contenido, en coordenadas del mundo -->
  </div>
</div>
```

```js
world.style.transform =
  `translateZ(${z}px) rotateX(${rotX}deg) rotateZ(${rotZ}deg) ` +
  `translate3d(${-x}px, ${-y}px, 0)`;
```

El orden importa: `translateZ` primero (distancia), luego rotación, luego
desplazamiento. Al revés, la cámara orbita en lugar de viajar.

**Todo cuelga de una función `seek(t)` determinista.** Nada de
`requestAnimationFrame` ni `setTimeout`: el render pide cuadros por tiempo
exacto, así que el mismo `t` debe dar siempre el mismo cuadro.

## Pipeline de render

**El recorrido completo, paso a paso, está en `references/pipeline.md`.** Léelo
al empezar un video; esta sección es solo el resumen.

`assets/render.py`, `assets/check.py` y `assets/mezcla_audio.py` están listos;
cópialos junto a tu `scene.html`. `assets/scene-ejemplo.html` es una escena real
y funcionando, con la cámara de curva continua ya resuelta.

```bash
python check.py    # solo tiempos clave: revisa encuadres (barato)
python render.py   # todos los cuadros
ffmpeg -y -framerate 30 -i frames/f%05d.png \
  -c:v libx264 -preset slow -crf 19 -pix_fmt yuv420p \
  -movflags +faststart out/video.mp4
```

Ajusta `DURATION`, `W`, `H` arriba de `render.py` y `TIMES` en `check.py`.

**Siempre corre `check.py` antes del render completo.** Un render de 960 cuadros
toma ~5 minutos; descubrir ahí que un texto se sale del encuadre es caro.

### Trampas verificadas (cuestan horas si no se saben)

| Síntoma | Causa | Arreglo |
|---|---|---|
| `height not divisible by 2` en ffmpeg | `--window-size` incluye el cromo: el viewport real es menor (1064×985) | `Emulation.setDeviceMetricsOverride` por CDP — ya está en `render.py` |
| Tipografía sale en serif | El archivo de fuente se descargó corrupto (404 guardado como .ttf) | Verifica los magic bytes: `head -c 4 f.ttf \| xxd -p` → `00010000` |
| Handshake 403 al conectar | Chrome rechaza el origen del websocket | `--remote-allow-origins=*` |
| Chrome arranca pero no carga nada | Perfil bloqueado por otra instancia | Perfil único por corrida (ya está en `render.py`) |
| `@font-face` no carga | `file://` bloquea las fuentes | Servir por HTTP local (ya está en `render.py`) |

Para fuentes variables de Google Fonts, la ruta es
`ofl/<familia>/<Familia>[wght].ttf`, **no** `static/`. Declara el rango:
`font-weight: 300 700` y `format('truetype-variations')`.

## Audio

**Busca una pista, no inventes sonido.** El error más caro de esta skill fue
sintetizar un "ambiente de sala de control" (un tono de 50 Hz sostenido): suena
a cable mal conectado y clippea. Pixabay tiene música libre de regalías; úsala.

### Elegir la pista
Busca por **el tema de la marca**, no por el género que te parezca cinematográfico.
Para una marca de enseñanza técnica: `minimal focus documentary`,
`ambient technology`, `minimal techno background`. Evita "corporate" (choca con
casi cualquier guardrail de tono) y "cyberpunk/dark" salvo que la marca lo pida.

Cuando una pista tiene variantes (full / drumless / loop edit), mídelas y elige:

```
FULL      grave 21% medio 65% agudo 14%  golpes/min 77  variacion 0.30
DRUMLESS  grave  0% medio 89% agudo 11%  golpes/min 85  variacion 0.22
LOOP EDIT grave 21% medio 66% agudo 13%  golpes/min 56  variacion 0.18  <- esta
```

Gana la de **menos golpes por minuto y menor variación**: es cama, no
protagonista, y no compite con el texto. La drumless suele perder todo el grave.

De una pista larga, toma el tramo de 32s **más parejo** (menor `std/mean` de la
envolvente), no los primeros 32s: así no caes en un cambio de sección.

### SFX: pocos, suaves, con un porqué
Son whooshes que acompañan el movimiento de cámara — **no** sonidos "temáticos"
inventados (relés, beeps de instrumento). Reglas:

- **Dos o tres por video**, nunca más. Cada uno marca un movimiento real de
  cámara: el gran zoom de apertura, la llegada al remate.
- **+8 a +10 dB de sonoridad sobre la cama musical.** Ese es el rango donde un
  sonido resalta sin aplastar. Medido en dB de sonoridad, NO en picos de muestra
  (ver abajo: un whoosh a "1.8x el pico" se oye apenas +2 dB, o sea nada).
- Si no puedes nombrar qué movimiento acompaña un SFX, sácalo.

### Mezcla

Usa `assets/mezcla_audio.py`, que balancea por sonoridad y verifica solo:

```bash
python mezcla_audio.py --musica cama.mp3 --salida audio.wav --dur 32 \
  --desde 57 \
  --sfx whoosh.mp3@6.0 --sfx whoosh.mp3@22.6 \
  --bajar 13.5:15.9:0.40
```

`--desde` toma el tramo más parejo de una pista larga; `--bajar` agacha la
música durante el freno narrativo para que el silencio se oiga.

Mezcla a mano con numpy, nunca con `loudnorm` + `sidechaincompress` + `amix`
encadenados: aplastan el rango y hacen desaparecer los golpes. Pico final por
debajo de 0.95 — **si pasa de 1.0 distorsiona**.

### Cómo verificar audio sin oírlo

**Los picos de muestra mienten sobre el volumen.** El oído percibe energía
sostenida, no la altura de una muestra. Una música continua y un whoosh de
medio segundo al mismo pico se oyen muy distinto: el whoosh queda enterrado.
Este error produjo una entrega donde el usuario tuvo que bajarle el volumen
y aun así no oía los SFX.

Balancea siempre por **sonoridad** (energía en ventanas de 400 ms):

```python
def son_mediana(x, sr):          # nivel tipico de una cama continua
    w, hop = int(0.4*sr), int(0.1*sr)
    m = x.mean(axis=1) if x.ndim > 1 else x
    return float(np.median([10*np.log10(np.mean(m[i:i+w]**2)+1e-12)
                            for i in range(0, len(m)-w, hop)]))

def son_activa(x, sr):           # para un SFX corto: su ventana MAS fuerte,
    w, hop = int(0.4*sr), int(0.05*sr)   # no su promedio (que incluye silencio)
    m = x.mean(axis=1) if x.ndim > 1 else x
    if len(m) <= w: return 10*np.log10(np.mean(m**2)+1e-12)
    return 10*np.log10(max(np.mean(m[i:i+w]**2)
                           for i in range(0, len(m)-w, hop)) + 1e-12)

# Escala cada capa a su objetivo
mus = mus * 10**((-22.0 - son_mediana(mus, sr))/20)   # cama
sfx = sfx * 10**((-14.0 - son_activa(sfx, sr))/20)    # +8 dB sobre la cama
```

Medir la sonoridad del SFX con `son_mediana` da un número absurdo (su silencio
cuenta) y lo escala al cielo: usa `son_activa` para los sonidos cortos.

**Comprueba el resultado con EBU R128**, que es el estándar de percepción:

```bash
ffmpeg -hide_banner -i out/video.mp4 -af ebur128=framelog=quiet -f null - 2>&1 | grep -A7 Summary
```

- `I` (sonoridad integrada): **-20 a -23 LUFS** para redes. Si da -18 o más
  alto, el usuario va a tener que bajarle el volumen.
- `LRA` (rango dinámico): **5 LU o más**. Un LRA de 3 significa que todo suena
  igual de fuerte y nada resalta — ese es el síntoma de "hay mucho desmadre".

Revisa también el espectro: si una sola frecuencia domina (un pico aislado en
50 Hz, por ejemplo) es un tono sintético, no un ambiente — suena mal.

**Límite honesto:** estas medidas dicen si el audio está técnicamente sano, no
si suena bien. No puedes oírlo. Cuando el usuario diga que suena mal, créele
antes que a tus números, y pregúntale qué debe sonar en lugar de adivinar otra
vez.

## Verificación antes de entregar

1. **Continuidad:** ningún cuadro idéntico al anterior salvo en el freno
   deliberado.
   ```bash
   ffmpeg -i out/video.mp4 -vf "tblend=all_mode=difference,blackframe=amount=0:threshold=24" -f null -
   ```
2. **Tira de contacto:** el arco completo de un vistazo. Si una frase aparece en
   un solo cuadro de la tira, está apareciendo en vez de habitando.
   ```bash
   ffmpeg -i out/video.mp4 -vf "select='not(mod(n\,80))',scale=256:256,tile=4x3" -frames:v 1 contacto.png
   ```
3. **Duración exacta** y `pix_fmt=yuv420p` (sin esto no reproduce en algunos
   teléfonos).
4. **Legibilidad en celular:** mira la tira al 25%. Si no se lee ahí, el texto es
   chico. Es la prueba que más defectos revela: el texto cortado en los bordes y
   los bloques de información que se vuelven manchas grises solo se ven aquí.
   ```bash
   ffmpeg -i out/video.mp4 -vf "select='not(mod(n\,96))',scale=180:180,tile=5x2" -frames:v 1 celular.png
   ```
5. **Mute:** el video debe funcionar sin audio. Si depende del sonido, falló.
6. **Audio sano:** pico por debajo de 1.0 (sin clipping), `I` entre -20 y
   -23 LUFS, `LRA` de 5 LU o más, los SFX a +8 dB de sonoridad sobre la cama, y
   ninguna frecuencia única dominando el espectro.

## Errores que delatan el default

- Fade-up idéntico en cada bloque (es la firma del motion genérico).
- Partículas, destellos o parallax sin significado narrativo.
- Cámara que orbita sin razón: el movimiento debe decir algo.
- Mundo que es solo un plano plano con textura — sin profundidad real no hay
  espacio.
- Más de 2 elementos en el HUD.
- Rotaciones grandes, rebotes o elásticos en marcas técnicas.
- Countup en cifras: el dato aparece completo.
- **Audio inventado**: tonos sintetizados, "diseño sonoro" conceptual, o cuatro
  capas sonando a la vez. Una pista + dos whooshes basta.
- **Easing por tramo** en la cámara (el acordeón). Es el defecto que más se
  siente y el que menos se ve en cuadros sueltos.

## Qué respetar de la marca

Si existe un Brand Profile, **el movimiento también está ahí**: su firma de
movimiento (carácter, curvas, duraciones, gesto de revelación) manda sobre
cualquier default de esta skill. Esta skill define *cómo se construye el
espacio*; la marca define *cómo se siente moverse en él*.
