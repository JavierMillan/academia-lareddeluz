"""Captura solo unos tiempos clave para revisar diseño antes del render completo."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import render as R

TIMES = [0.6, 4.0, 7.2, 9.0, 12.0, 15.0, 18.5, 20.5, 24.0, 27.5, 31.5]


def main():
    import base64, json, shutil, subprocess, threading, time, urllib.request
    from http.server import ThreadingHTTPServer

    HERE = R.HERE
    OUT = os.path.join(HERE, "check")
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)

    http_port = R.free_port()
    srv = ThreadingHTTPServer(("127.0.0.1", http_port), R.Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()

    dbg_port = R.free_port()
    profile = os.path.join(HERE, f".chrome-chk-{os.getpid()}-{int(time.time())}")
    proc = subprocess.Popen([
        R.CHROME, "--headless=new", f"--remote-debugging-port={dbg_port}",
        "--remote-allow-origins=*", f"--user-data-dir={profile}",
        f"--window-size={R.W},{R.H}", "--hide-scrollbars",
        "--force-device-scale-factor=1", "--disable-gpu", "--no-first-run",
        "--no-default-browser-check", "--disable-extensions", "--mute-audio",
        "about:blank",
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    ws_url = None
    for _ in range(150):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{dbg_port}/json") as r:
                for t in json.load(r):
                    if t.get("type") == "page" and t.get("webSocketDebuggerUrl"):
                        ws_url = t["webSocketDebuggerUrl"]
                        break
            if ws_url:
                break
        except Exception:
            pass
        time.sleep(0.2)

    from websocket import create_connection
    ws = create_connection(ws_url, timeout=30)
    mid = [0]

    def cmd(method, params=None):
        mid[0] += 1
        i = mid[0]
        ws.send(json.dumps({"id": i, "method": method, "params": params or {}}))
        while True:
            d = json.loads(ws.recv())
            if d.get("id") == i:
                if "error" in d:
                    raise RuntimeError(f"{method}: {d['error']}")
                return d.get("result", {})

    cmd("Page.enable")
    cmd("Runtime.enable")
    cmd("Page.navigate", {"url": f"http://127.0.0.1:{http_port}/scene.html"})
    for _ in range(150):
        v = cmd("Runtime.evaluate", {
            "expression": "document.readyState+'|'+(typeof window.seek)",
            "returnByValue": True})["result"].get("value", "")
        if v.startswith("complete") and v.endswith("function"):
            break
        time.sleep(0.2)
    for _ in range(80):
        if cmd("Runtime.evaluate", {"expression": "document.fonts.status",
                                    "returnByValue": True})["result"].get("value") == "loaded":
            break
        time.sleep(0.25)

    # Verifica que CADA fuente declarada esté REALMENTE aplicada y no sea un
    # fallback del sistema: compara el ancho de un texto en esa familia contra
    # serif y sans-serif. Si coincide con alguno, la fuente no cargó.
    probe = cmd("Runtime.evaluate", {"expression": (
        "(() => {"
        " const fams = [...new Set([...document.fonts].map(f => f.family))];"
        " const span = document.createElement('span');"
        " span.textContent = 'ABCDEFGHIJ';"
        " span.style.cssText = 'position:absolute;left:-9999px;font-size:100px;font-weight:700;';"
        " document.body.appendChild(span);"
        " const widthOf = (f) => { span.style.fontFamily = f;"
        "   return span.getBoundingClientRect().width; };"
        " const wSerif = widthOf('serif'), wSans = widthOf('sans-serif');"
        " const out = fams.map((f) => { const w = widthOf(f);"
        "   return {font: f, ok: Math.abs(w-wSerif) > 2 && Math.abs(w-wSans) > 2}; });"
        " span.remove();"
        " return JSON.stringify({status: document.fonts.status, fuentes: out});"
        "})()"), "returnByValue": True})["result"].get("value")
    print("FONT PROBE:", probe)
    if probe and '"ok":false' in probe.replace(" ", ""):
        print("  ⚠ Alguna fuente cayó a fallback del sistema — revisa los .ttf")

    for t in TIMES:
        cmd("Runtime.evaluate", {"expression": f"window.seek({t}); true", "returnByValue": True})
        shot = cmd("Page.captureScreenshot", {"format": "png"})
        p = os.path.join(OUT, f"t{str(t).replace('.', '_')}.png")
        with open(p, "wb") as fh:
            fh.write(base64.b64decode(shot["data"]))
    print("OK check frames:", OUT)

    ws.close()
    proc.terminate()
    srv.shutdown()


if __name__ == "__main__":
    main()
