"""Mezcla una cama musical con SFX cortos, balanceando por SONORIDAD.

Los picos de muestra mienten sobre el volumen percibido: una musica continua y
un whoosh de medio segundo al mismo pico se oyen muy distinto. Este script
escala cada capa por su energia en ventanas de 400 ms, que es como percibe el
oido, y verifica el resultado con EBU R128.

Uso:
    python mezcla_audio.py --musica cama.mp3 --salida audio.wav --dur 32 \
        --sfx whoosh.mp3@6.0 --sfx whoosh.mp3@22.6 \
        --bajar 13.5:15.9:0.40

    --sfx  ARCHIVO@SEGUNDO     (repetible)
    --bajar INI:FIN:FACTOR     baja la musica en ese tramo (para un silencio
                               narrativo); repetible
"""
import argparse, subprocess, sys, wave
import numpy as np

SR = 48000
CAMA_DB = -22.0      # sonoridad objetivo de la musica
SFX_DB = -14.0       # +8 dB sobre la cama: resalta sin aplastar


def leer(path, ch=2):
    raw = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", path, "-f", "f32le",
         "-ac", str(ch), "-ar", str(SR), "-"],
        capture_output=True).stdout
    if not raw:
        sys.exit(f"ERROR: no se pudo leer {path}")
    return np.frombuffer(raw, dtype=np.float32).astype(np.float64).reshape(-1, ch)


def _mono(x):
    return x.mean(axis=1) if x.ndim > 1 else x


def son_mediana(x):
    """Sonoridad tipica de una señal continua (la cama)."""
    m = _mono(x)
    w, hop = int(0.4*SR), int(0.1*SR)
    if len(m) <= w:
        return 10*np.log10(np.mean(m**2) + 1e-12)
    return float(np.median([10*np.log10(np.mean(m[i:i+w]**2) + 1e-12)
                            for i in range(0, len(m)-w, hop)]))


def son_activa(x):
    """Sonoridad de la parte que SUENA — para SFX cortos.

    Usar son_mediana con un SFX da un valor absurdo (su silencio cuenta) y lo
    escala al cielo.
    """
    m = _mono(x)
    w, hop = int(0.4*SR), int(0.05*SR)
    if len(m) <= w:
        return 10*np.log10(np.mean(m**2) + 1e-12)
    return 10*np.log10(max(np.mean(m[i:i+w]**2)
                           for i in range(0, len(m)-w, hop)) + 1e-12)


def a_sonoridad(x, objetivo, medidor):
    return x * 10**((objetivo - medidor(x)) / 20)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--musica", required=True)
    ap.add_argument("--salida", required=True)
    ap.add_argument("--dur", type=float, required=True)
    ap.add_argument("--sfx", action="append", default=[],
                    help="archivo@segundo")
    ap.add_argument("--bajar", action="append", default=[],
                    help="ini:fin:factor")
    ap.add_argument("--desde", type=float, default=0.0,
                    help="segundo de la musica desde donde cortar")
    ap.add_argument("--cama-db", type=float, default=CAMA_DB)
    ap.add_argument("--sfx-db", type=float, default=SFX_DB)
    a = ap.parse_args()

    N = int(a.dur * SR)
    mus = leer(a.musica)
    ini = int(a.desde * SR)
    mus = mus[ini:ini+N]
    if len(mus) < N:
        mus = np.vstack([mus, np.zeros((N - len(mus), 2))])

    mus = a_sonoridad(mus, a.cama_db, son_mediana)

    # Bajadas de volumen (silencios narrativos)
    for spec in a.bajar:
        i0, i1, f = spec.split(":")
        s, e, fac = int(float(i0)*SR), int(float(i1)*SR), float(f)
        rampa = int(0.25*SR)
        mus[s:e] *= fac
        for k, (p, q) in enumerate(((s-rampa, s), (e, e+rampa))):
            if p < 0 or q > N:
                continue
            curva = np.linspace(1, fac, rampa) if k == 0 else np.linspace(fac, 1, rampa)
            mus[p:q] *= curva[:, None]

    # Fundidos de entrada y salida
    fi, fo = int(1.8*SR), int(2.8*SR)
    mus[:fi] *= np.linspace(0, 1, fi)[:, None]
    mus[-fo:] *= np.linspace(1, 0, fo)[:, None]

    mix = mus.copy()
    puestos = []
    for spec in a.sfx:
        path, _, seg = spec.rpartition("@")
        snd = a_sonoridad(leer(path), a.sfx_db, son_activa)
        i = int(float(seg) * SR)
        j = min(N, i + len(snd))
        if i >= N:
            continue
        mix[i:j] += snd[:j-i]
        puestos.append(float(seg))

    pk = np.abs(mix).max()
    if pk > 0.95:
        mix *= 0.95 / pk
        print(f"  (limitado: pico era {pk:.2f})")

    with wave.open(a.salida, "w") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(mix, -1, 1) * 32767).astype("<i2").tobytes())

    # ── Verificacion ──
    m = _mono(mix)
    w_, hop = int(0.4*SR), int(0.1*SR)
    T, D = [], []
    for i in range(0, len(m)-w_, hop):
        T.append(i/SR); D.append(10*np.log10(np.mean(m[i:i+w_]**2) + 1e-12))
    T, D = np.array(T), np.array(D)
    med = np.median(D)
    print(f"OK {a.salida}   pico {np.abs(mix).max():.3f}   cama {med:.1f} dB")
    for s in puestos:
        k = (T >= s-0.3) & (T <= s+1.2)
        if k.any():
            print(f"   SFX {s:5.1f}s  +{D[k].max()-med:.1f} dB sobre la cama"
                  f"{'   <- BAJO (busca +8)' if D[k].max()-med < 6 else ''}")

    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", a.salida,
                        "-af", "ebur128=framelog=quiet", "-f", "null", "-"],
                       capture_output=True, text=True).stderr
    for linea in r.splitlines():
        if "I:" in linea or "LRA:" in linea:
            print("   " + linea.strip())
    print("   objetivo: I entre -20 y -23 LUFS, LRA 5 LU o mas")


if __name__ == "__main__":
    main()
