"""Renderiza scene.html a frames PNG con Chrome headless (CDP), 30fps."""
import base64, json, os, shutil, socket, subprocess, sys, threading, time, urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
FPS = 30
DURATION = 32.0
W = H = 1080
FRAMES = int(round(FPS * DURATION))
OUT = os.path.join(HERE, "frames")

CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=HERE, **kw)

    def log_message(self, *a):
        pass


def main():
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)

    # Servidor local: file:// bloquea @font-face en headless.
    http_port = free_port()
    srv = ThreadingHTTPServer(("127.0.0.1", http_port), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()

    dbg_port = free_port()
    # Perfil único por corrida: un perfil reutilizado queda bloqueado por una
    # instancia previa y Chrome arranca sin cargar la URL.
    profile = os.path.join(HERE, f".chrome-{os.getpid()}-{int(time.time())}")
    proc = subprocess.Popen(
        [
            CHROME,
            "--headless=new",
            f"--remote-debugging-port={dbg_port}",
            "--remote-allow-origins=*",
            f"--user-data-dir={profile}",
            f"--window-size={W},{H}",
            "--hide-scrollbars",
            "--force-device-scale-factor=1",
            "--disable-gpu",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-extensions",
            "--mute-audio",
            "about:blank",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    page_url = f"http://127.0.0.1:{http_port}/scene.html"

    # Espera cualquier target de página; la URL se carga luego por CDP.
    ws_url = None
    for _ in range(150):
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{dbg_port}/json") as r:
                tabs = json.load(r)
            for t in tabs:
                if t.get("type") == "page" and t.get("webSocketDebuggerUrl"):
                    ws_url = t["webSocketDebuggerUrl"]
                    break
            if ws_url:
                break
        except Exception:
            pass
        time.sleep(0.2)

    if not ws_url:
        print("ERROR: no se pudo conectar a Chrome", file=sys.stderr)
        proc.kill()
        return 1

    try:
        from websocket import create_connection
    except ImportError:
        print("NEEDS_WEBSOCKET_CLIENT", file=sys.stderr)
        proc.kill()
        return 2

    ws = create_connection(ws_url, timeout=30)
    msg_id = [0]

    def cmd(method, params=None):
        msg_id[0] += 1
        mid = msg_id[0]
        ws.send(json.dumps({"id": mid, "method": method, "params": params or {}}))
        while True:
            data = json.loads(ws.recv())
            if data.get("id") == mid:
                if "error" in data:
                    raise RuntimeError(f"{method}: {data['error']}")
                return data.get("result", {})

    cmd("Page.enable")
    cmd("Runtime.enable")

    # Viewport exacto: --window-size incluye el cromo del navegador, así que
    # el área de captura queda más chica (1064x985) y recorta la composición.
    cmd("Emulation.setDeviceMetricsOverride", {
        "width": W, "height": H, "deviceScaleFactor": 1, "mobile": False,
    })

    # Carga la escena y espera a que el DOM esté listo
    cmd("Page.navigate", {"url": page_url})
    for _ in range(150):
        r = cmd("Runtime.evaluate", {
            "expression": "document.readyState + '|' + (typeof window.seek)",
            "returnByValue": True,
        })
        val = r.get("result", {}).get("value") or ""
        if val.startswith("complete") and val.endswith("function"):
            break
        time.sleep(0.2)

    # Espera a que las fuentes carguen de verdad
    for _ in range(80):
        r = cmd("Runtime.evaluate", {
            "expression": "document.fonts.status",
            "returnByValue": True,
        })
        if r.get("result", {}).get("value") == "loaded":
            break
        time.sleep(0.25)

    # Chequeo: ¿seek existe y las fuentes de marca están activas?
    chk = cmd("Runtime.evaluate", {
        "expression": (
            "JSON.stringify({seek: typeof window.seek,"
            " fonts: document.fonts.status,"
            " sg: document.fonts.check('700 92px SG'),"
            " jbm: document.fonts.check('14px JBM'),"
            " cifra: document.getElementById('cifra').getBoundingClientRect().width})"
        ),
        "returnByValue": True,
    })
    print("CHECK:", chk.get("result", {}).get("value"))

    t0 = time.time()
    for i in range(FRAMES):
        t = i / FPS
        cmd("Runtime.evaluate", {"expression": f"window.seek({t:.5f}); true",
                                 "returnByValue": True})
        shot = cmd("Page.captureScreenshot", {"format": "png",
                                              "captureBeyondViewport": False})
        with open(os.path.join(OUT, f"f{i:05d}.png"), "wb") as fh:
            fh.write(base64.b64decode(shot["data"]))
        if i % 90 == 0:
            el = time.time() - t0
            print(f"  frame {i}/{FRAMES}  ({el:.0f}s)", flush=True)

    ws.close()
    proc.terminate()
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()
    srv.shutdown()
    print(f"OK {FRAMES} frames en {time.time() - t0:.0f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
