# Guía desde cero — hacer un video sin saber de esto

Para alguien que nunca ha renderizado nada. No necesitas programar: le pides a
Claude Code y él hace el trabajo. Tu papel es **decidir y juzgar**, que es la
parte que ninguna máquina hace por ti.

---

## Qué estamos haciendo, en una frase

Una página web secreta que nadie va a visitar: se le toma una foto 30 veces por
segundo, y esas 960 fotos se pegan en un video. Por eso se puede controlar cada
detalle con precisión y no hace falta un editor de video.

---

## Lo que necesitas instalado

Solo dos cosas, y probablemente ya las tienes:

| Qué | Para qué | Cómo saber si está |
|---|---|---|
| **Google Chrome** | toma las fotos | ¿lo abres normalmente? listo |
| **ffmpeg** | pega las fotos en video | escribe `ffmpeg -version` en la terminal |

Si ffmpeg no está, pídeselo a Claude: *"instálame ffmpeg"*.

---

## Los 6 pasos

### 1. Junta tu material (10 minutos, tú)

Antes de pedir nada, ten a la mano:

- **Las frases exactas** que van a aparecer. Esto es lo más importante del
  video: si el texto es flojo, ninguna animación lo salva.
- **Los colores de tu marca** (los códigos tipo `#0D1117`).
- **Las tipografías** que usas.
- **Qué quieres que haga** quien lo vea: escribirte, dar clic, guardarlo.

¿No tienes las frases? Pídeselas a Claude primero, apruébalas, y **luego**
pides el video. No mezcles las dos cosas: corregir texto con el video ya hecho
cuesta mucho más.

### 2. Pide el video

Abre Claude Code en la carpeta de tu proyecto y pega el master prompt
(`master-prompt.md`), relleno con tus datos. O más corto, si tienes la skill:

> `/animador-reels` — hazme un video de 30 segundos para [marca], formato
> cuadrado para WhatsApp. El guion es: [tus frases]. Los colores son [...].

### 3. Aprueba el concepto (tú decides)

Claude te va a proponer **dónde ocurre el video** antes de animar nada. No lo
saltes: aquí es donde se decide si el video se ve como el de todos o como
tuyo. Pregúntate:

- ¿Este mundo tiene que ver con lo que hago, o es decoración bonita?
- ¿Alguien de mi competencia podría usar exactamente esto? Si sí, pide otra.

### 4. Revisa los encuadres (2 minutos, importante)

Claude te enseña unas cuantas imágenes sueltas antes de renderizar todo.
**Míralas con cuidado**, porque arreglar aquí cuesta un minuto y arreglar
después cuesta seis.

Busca específicamente:
- ¿Se lee el texto **completo**, sin que se corte en los bordes?
- ¿Lo importante está centrado o se fue a una esquina?

### 5. Espera el render (5-6 minutos, la máquina)

Son 960 fotos. Puedes hacer otra cosa mientras.

### 6. Júzgalo tú (lo más importante)

Claude mide cosas pero **no puede ver ni oír**. El juicio es tuyo. Velo así:

1. **En el celular, no en la compu.** Mándatelo por WhatsApp y míralo ahí: es
   donde lo va a ver la gente.
2. **Sin sonido primero.** ¿Se entiende? Mucha gente ve en silencio.
3. **Con sonido después.** ¿Tienes que bajarle el volumen? Entonces está muy
   fuerte: dilo.
4. **Los primeros 3 segundos.** Si no engancha ahí, no hay segundo 10.

---

## Cómo pedir cambios (que te entiendan)

Describe **qué se siente mal**, no qué botón mover. Claude mide y diagnostica.

| En vez de... | Di... |
|---|---|
| "súbele 3 dB al whoosh" | "el whoosh casi no se escucha y la música está fuerte" |
| "cambia el easing" | "se siente como diapositivas, no fluye" |
| "mueve el texto 40px" | "el texto se sale por la izquierda" |

Y si algo no te late pero no sabes por qué, dilo tal cual: *"no me convence,
revísalo y dime qué está mal"*. Hay herramientas para diagnosticarlo.

---

## Lo que sale mal seguido (y qué decir)

| Lo que ves | Qué decir |
|---|---|
| Parece presentación de PowerPoint | "está como diapositivas, necesito que la cámara se mueva en un espacio" |
| Avanza a tirones | "el movimiento va en sacudidas, no es parejo" |
| El texto se corta | "el texto se sale del encuadre" |
| No se lee en el celular | "a tamaño celular no se lee, agranda el texto" |
| Tuviste que bajarle el volumen | "está muy fuerte el audio en general" |
| El video "termina" antes de acabarse | "los últimos segundos están congelados" |

---

## Las reglas que no deberías dejar romper

Aunque no sepas de animación, estas se juzgan con el ojo:

1. **Una sola pausa.** Si el video se detiene varias veces, está mal.
2. **El color de la marca entra una vez** y en el momento importante. Si está
   por todos lados, deja de significar algo.
3. **Dos o tres sonidos**, no más. Si suena a desmadre, es que hay de más.
4. **Se entiende sin sonido.**
5. **Se lee en el celular.**

---

## Preguntas comunes

**¿Puedo cambiar una frase sin rehacer todo?**
Sí. Es cambiar el texto y volver a renderizar: unos 6 minutos.

**¿Sirve para otra marca?**
Sí, pero cambia el mundo y los colores. Si solo cambias el logo, se nota.

**¿Y la música es legal?**
Sí, si viene de Pixabay: es libre de regalías, incluso para publicidad. Pide
siempre el link de la pista y guárdalo.

**¿Por qué no usar CapCut o Premiere?**
Puedes. La ventaja de esto es la precisión (posiciones exactas, mismo resultado
siempre) y que repetir el video con otro texto es un cambio de una línea. La
desventaja es que no lo ves en vivo mientras lo haces.

**¿Dónde quedan los archivos?**
Pregunta: *"¿dónde quedó el video?"*. Ojo: si está en una carpeta temporal,
muévelo a tu carpeta de proyecto o se borra.
