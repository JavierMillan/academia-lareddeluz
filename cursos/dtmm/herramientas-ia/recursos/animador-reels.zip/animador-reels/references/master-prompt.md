# Master prompt — video de motion graphics espacial

Copia el bloque de abajo, rellena los corchetes y pégalo en Claude Code.
Funciona sin la skill instalada (lleva las reglas dentro), pero si tienes
`/animador-reels` basta con invocarla y dar los datos.

---

## El prompt

```
Hazme un video de motion graphics para [MARCA].

CONTEXTO
- Qué vende: [producto o servicio en una frase]
- A quién: [público, y qué le quita el sueño]
- Dónde se publica: [WhatsApp / Instagram / etc.]
- Formato: [1080x1080 cuadrado | 1080x1920 vertical], [30] segundos
- Objetivo: que escriban a [WhatsApp / DM / link]

IDENTIDAD VISUAL
- Colores: [fondo #______, acento #______]
- Tipografías: [titulares ______, texto ______, datos ______]
- Reglas de la marca: [lo que NUNCA debe aparecer]
(Si existe un Brand Profile o design system, úsalo como fuente de verdad.)

EL GUION
[Escribe las frases tal cual van a aparecer, en orden. Si no las tienes,
pídeme que las escriba antes de animar.]

CÓMO DEBE SER EL VIDEO
Esto NO es una presentación con texto que entra y sale. Es una sola toma
continua de cámara moviéndose dentro de un espacio que existe:

1. Define primero EL MUNDO donde ocurre, derivado del ADN de la marca
   (un plano técnico, un pliego de revista, un gráfico navegable...).
   Nunca "fondo oscuro con partículas".
2. El texto YA ESTÁ escrito en ese mundo. No aparece: la cámara llega a él.
   Técnicamente, su opacidad va de 0.08 a 1, nunca de 0 a 1.
3. Una sola toma, cero cortes. La cámara arranca una vez y asienta una vez.
   Interpola los keyframes con Catmull-Rom, NO con easing por tramo
   (eso produce un "acordeón": arrancones y valles muertos).
4. Un solo freno de 1-2 segundos donde el guion tenga su silencio. Es la
   ÚNICA pausa del video, por eso significa algo.
5. El color de acento entra UNA vez, en el momento del giro narrativo.
6. El remate vive en el lugar que le toca dentro del mundo (el cajetín de
   un plano, el pie de una página), no en una tarjeta que aparece al final.

OJO: "una toma" y "un freno" NO significan lento. Pasa algo cada 2-3
segundos, y por eso el freno se nota.

PRIMERO LA HISTORIA
- Una ESCENA que la persona vive, no la explicación de un concepto.
- Acciones, no etiquetas ("te levantas, trabajas, celular, duermes…").
- En 3 segundos ya se entiende de qué va; un protagonista por frase.
- La última frase regresa a la primera (loop). CTA con palabra clave.
- Antes de animar: tabla segundo → frase → lo único que se ve.

NIVEL CINE
- Una cosa se convierte en la siguiente; nada se esfuma para dejar paso.
- Capas a distintas distancias con desenfoque por distancia.
- Cámara que arranca rápido y frena suave; desenfoque de movimiento en lo
  rápido (render.py --mb 6).
- Negros cálidos, viñeta y grano leve.
- Celular: títulos ≥ 100 px, textos ≥ 72 px; el CTA a media pantalla.

AUDIO
- Una pista de Pixabay buscada por EL TEMA de la marca, no por género
  cinematográfico. Para enseñanza técnica: "minimal focus documentary",
  "ambient technology", "minimal techno background".
- Cada cosa que aparece suena (pop, clic, golpe suave). Whooshes solo
  sobre movimientos reales de cámara. Nada de sonidos "temáticos"
  inventados.
- Corta la música en seco en la frase más importante.
- Balance por SONORIDAD, no por picos: los SFX a +8/+10 dB sobre la música.
- Verifica con EBU R128: I entre -20 y -23 LUFS, LRA de 5 LU o más.

PROHIBIDO
- Fade-up idéntico en cada bloque, partículas, parallax decorativo.
- Rebotes o elásticos (salvo que la marca lo pida).
- Countup en cifras: el número aparece completo.
- Más de 2 elementos pegados a la cámara (HUD).

ANTES DE ENTREGAR, VERIFICA Y MUÉSTRAME
- Tira de contacto del arco completo.
- Tira a 180px (tamaño celular real): si no se lee ahí, el texto es chico.
- Curva de energía de movimiento: debe tener UN solo valle.
- Sonoridad: I y LRA dentro de objetivo.
- Revisión ciega: califícalo como alguien que no sabe nada del video y
  arregla lo que encuentres.

Antes del video completo, hazme 5 segundos de prueba del momento más
importante. Revisa los encuadres con pocos cuadros ANTES de renderizar todo.
```

---

## Variantes útiles

**Si ya tienes posts y quieres el video a partir de ellos:**
> Toma estos dos posts [adjuntar] y haz el video. Respeta sus códigos visuales,
> pero no los animes como diapositivas: construye el mundo espacial.

**Si quieres solo el guion primero:**
> Antes de animar, escríbeme el guion con tiempos: tabla de escena, entra-sale,
> texto en pantalla y qué hace la cámara. Lo apruebo y luego produces.

**Si algo se siente mal y no sabes qué:**
> Se siente [como diapositivas / acelerado / plano]. Mide el ritmo con la curva
> de energía y los encuadres con la tira de celular, y dime qué está mal antes
> de cambiar nada.

## Qué esperar

- Primer render: 5-6 minutos para 30 segundos.
- Revisión de encuadres: menos de 1 minuto. **Siempre hazla antes.**
- El resultado es un MP4 de ~6 MB, listo para WhatsApp e Instagram.
