# Pipeline completo — de un guion a un MP4 con audio

El recorrido entero, en orden, con los puntos donde se verifica. Pensado para
repetirse sin volver a descubrir las trampas.

## 0. Antes de escribir código

Tres cosas decididas por escrito, o el video sale genérico:

1. **El mundo**: dónde ocurre, derivado del ADN de la marca (un plano técnico,
   un pliego editorial, un gráfico navegable). Nunca "fondo oscuro con
   partículas".
2. **El guion con tiempos**: una tabla de escena · entra–sale · texto · gesto.
   Se escribe antes de animar, no después.
3. **El Brand Profile**, si existe: su firma de movimiento manda sobre
   cualquier default de esta skill.

## 1. Montar la carpeta

```
proyecto/
  scene.html          <- la escena (copiar assets/scene-ejemplo.html)
  render.py           <- de assets/
  check.py            <- de assets/
  mezcla_audio.py     <- de assets/
  fonts/              <- las fuentes de la marca
```

Fuentes variables de Google Fonts: la ruta es
`ofl/<familia>/<Familia>[wght].ttf`, **no** `static/`. Verifica siempre que
bajaron bien:

```bash
head -c 4 fonts/*.ttf | xxd -p     # 00010000 = válido; otra cosa = error guardado como .ttf
```

## 2. Construir la escena

Ver SKILL.md (Implementación). Lo esencial: `#viewport` con `perspective`,
`#world` con `preserve-3d`, todo colgando de un `seek(t)` determinista.

Calcula los encuadres antes de animar: `escala = perspective / (perspective - z)`.
Si el texto clave no baja de ~110 px aparentes, está cortado todo el video.

## 3. Revisar encuadres (barato)

```bash
python check.py        # ajusta TIMES a los momentos clave
```

Mira los PNG. Corrige aquí lo que esté cortado o descentrado: un render
completo son ~5 minutos y descubrirlo después sale caro.

## 4. Renderizar

```bash
python render.py       # ajusta DURATION, W, H arriba del archivo
python render.py --mb 6   # con desenfoque de movimiento en los cuadros rápidos (pip install numpy pillow)
```

## 5. Audio

Busca la pista por **el tema de la marca** (`minimal focus documentary`,
`ambient technology`), no por el género que parezca cinematográfico. Si tiene
variantes, gana la de menos golpes por minuto y menor variación.

```bash
python mezcla_audio.py --musica cama.mp3 --salida audio.wav --dur 32 \
  --desde 57 \
  --sfx whoosh.mp3@6.0 --sfx whoosh.mp3@22.6 \
  --bajar 13.5:15.9:0.40
```

El script imprime la verificación. Si un SFX sale por debajo de +6 dB, súbelo.

## 6. Unir

```bash
ffmpeg -y -framerate 30 -i frames/f%05d.png -i audio.wav \
  -c:v libx264 -preset slow -crf 19 -pix_fmt yuv420p \
  -c:a aac -b:a 192k -ar 48000 -ac 2 \
  -movflags +faststart -shortest out/video.mp4
```

`yuv420p` no es opcional: sin él no reproduce en varios teléfonos.

## 7. Verificar antes de entregar

```bash
# Continuidad: ningun cuadro repetido salvo el freno deliberado
ffmpeg -i out/video.mp4 -vf "tblend=all_mode=difference,blackframe=amount=0:threshold=24" -f null -

# Arco completo de un vistazo
ffmpeg -i out/video.mp4 -vf "select='not(mod(n\,80))',scale=256:256,tile=4x3" -frames:v 1 contacto.png

# Legibilidad real (la prueba que mas defectos revela)
ffmpeg -i out/video.mp4 -vf "select='not(mod(n\,96))',scale=180:180,tile=5x2" -frames:v 1 celular.png

# Sonoridad
ffmpeg -hide_banner -i out/video.mp4 -af ebur128=framelog=quiet -f null - 2>&1 | grep -A7 Summary
```

Umbrales: `I` entre -20 y -23 LUFS, `LRA` ≥ 5 LU, duración exacta,
`pix_fmt=yuv420p`, títulos ≥ 100 px y textos ≥ 72 px, CTA entre el 25 % y
el 70 % de la altura en vertical.

**Revisión ciega:** califica el video como un espectador frío. ¿Se entiende
sin contexto? ¿En qué segundo se aburre? ¿Hay un segundo en negro o algo que
no se lea? Con la skill Watch + Gemini puedes pedir que otro modelo vea el
MP4. Arregla todo antes de entregar.

## 8. Medir el ritmo (el defecto invisible)

La curva de energía de movimiento revela el acordeón, que no se ve en cuadros
sueltos:

```bash
ffmpeg -v error -i out/video.mp4 -vf "tblend=all_mode=difference,signalstats,metadata=print:key=lavfi.signalstats.YAVG:file=m.txt" -f null -
```

```python
import re, collections
t, v = [], []
for line in open('m.txt'):
    m = re.search(r'pts_time:([\d.]+)', line)
    if m: t.append(float(m.group(1)))
    m = re.search(r'YAVG=([\d.]+)', line)
    if m: v.append(float(m.group(1)))
b = collections.defaultdict(list)
for a, x in zip(t, v): b[int(a)].append(x)
avg = {s: sum(x)/len(x) for s, x in b.items()}
mx = max(avg.values())
for s in sorted(avg):
    print(f"{s:>3}s " + "#"*int(round(avg[s]/mx*34)))
```

**Un solo valle** (el freno narrativo). Varios valles = acordeón: el easing está
aplicado por tramo en vez de a la línea de tiempo global.

## Orden de las correcciones cuando algo se siente mal

De mayor a menor palanca, por experiencia:

1. **Ritmo** (acordeón, valles muertos, final congelado) — es lo que más se
   siente y lo que menos se ve en capturas.
2. **Encuadre** (texto cortado, protagonista descentrado).
3. **Legibilidad en celular** — revisa la tira a 180 px, no el video grande.
4. **Balance de audio** — por sonoridad, nunca por picos.
5. Detalles tipográficos y de color.

## Lo que no puedo verificar

No puedo oír el audio ni ver el video en movimiento: solo mido. Las métricas
dicen si algo está técnicamente sano, no si suena o se siente bien. Cuando el
usuario diga que algo está mal, créele antes que a los números y pregunta qué
debería pasar, en vez de adivinar otra vez.
