---
name: editor-corta
description: "Edita un video de alguien hablando a cámara como un editor de verdad, con el estándar CORTA (Cortes completos, Oído, Reacciona a mí, Texto, Animación con motivo): quita inicios vacíos, pausas largas y muletillas sin cortar a media frase; pone subtítulos con la palabra que se dice encendida; hace que lo que aparece nazca en la punta del dedo cuando la persona apunta; pone texto detrás de la persona; y mezcla voz, música y un sonido por cada cosa que aparece. Úsala cuando pidan editar un video, quitar silencios o muletillas, poner subtítulos, efectos que sigan las manos, o revisar si un video está bien editado. Necesita Claude Code (corre scripts de Python y ffmpeg)."
---

# Editor CORTA

Editas el video de la persona como lo haría un editor humano que sabe su oficio. Todo el trabajo sigue una palabra, **CORTA**, que es a la vez el orden de trabajo y la revisión final:

| Letra | Qué haces | Qué evitas |
|---|---|---|
| **C · Cortes completos** | Bloques completos de lo que la persona piensa | Cortes a media frase, inicio vacío, final colgado |
| **O · Oído** | Quitar pausas de más de medio segundo y muletillas; elegir la música | Silencios incómodos, palabras mochas |
| **R · Reacciona a mí** | Seguir sus manos, su cara y su silueta | Efectos lejos del dedo o encima de la cara |
| **T · Texto** | Subtítulos al ritmo de la voz | Subtítulos chicos o que terminan en "de" |
| **A · Animación con motivo** | Una cosa a la vez, cada una con su sonido; el cierre con su marca | Adornos, todo a la vez, cierres mudos |

Los scripts están en `scripts/` de esta skill. Se corren **desde la carpeta del video** (ahí se escriben todos los archivos de trabajo).

## Antes de empezar

1. Corre `python <skill>/scripts/verificar.py`. Si algo dice **[FALTA]**, dile a la persona qué falta y, con su permiso, instálalo (`pip install …`; ffmpeg con `winget install Gyan.FFmpeg` en Windows o `brew install ffmpeg` en Mac). Vuelve a correrlo hasta que diga "Todo listo".
2. Pregunta solo lo que falte: qué es el video y para quién, dónde se publica, sus colores y tipografías, su marca para el cierre y si tiene música. Si tiene un brand profile o usa la skill **Prism**, saca de ahí colores y fuentes.

## El trabajo, en orden C-O-R-T-A (con sus pausas)

### C y O · Cortar y escuchar
1. `python <skill>/scripts/transcribir.py VIDEO.mp4` → `transcripcion.txt` (para leer), `transcripcion.json` y **`tomas.json`**, una propuesta de bloques: quita el inicio vacío, las pausas de más de 0.6 s (dejando una respiración) y las muletillas ("eh", y "este" solo cuando va pegado a una pausa).
   - Si la computadora es lenta usa `--modelo small` (el que viene por defecto); si sobra GPU, `--modelo large-v3` transcribe mejor.
2. **Lee la transcripción completa, incluido el final.** Ajusta `tomas.json`: quita repeticiones ("me equivoqué, repito"), despedidas y frases colgadas al final. Nunca partas una frase a la mitad: es mejor dejar una pausa que cortar una palabra.
3. **Pausa:** enséñale a la persona qué vas a cortar (con tiempos) y espera su visto bueno.
4. `python <skill>/scripts/cortar.py VIDEO.mp4` → `corte.mp4` y `palabras.json`. Pídele que escuche los empalmes.

### R · Leer a la persona
5. `python <skill>/scripts/manos.py` → `manos.json` e imprime **cuándo apunta con el índice**. La mano llega **antes** que la palabra (en el caso real, dos segundos antes): usa esos tiempos, no los de la transcripción.
6. Si algo va **detrás** de la persona, recorta su silueta solo en esos tramos: `python <skill>/scripts/silueta.py 12.5-16`. Es lento; no lo corras en todo el video.
7. Si no hizo gestos, la R es su cara y su voz: un acercamiento (`zoom`) cuando sube el tono y quietud en la frase más fuerte.

### T y A · Texto y lo que aparece
8. Escribe `estilo.json` (opcional) con su marca:
   ```json
   {"fuente_subtitulos": "ruta/a/su-fuente.ttf", "fuente_titulos": "",
    "color_texto": "#FFFFFF", "color_acento": "#FFCB05",
    "color_etiqueta_fondo": "#FFCB05", "color_etiqueta_texto": "#111111",
    "subtitulos": {"tam": 0.085, "y": 0.70, "max_palabras": 3, "mayusculas": true},
    "clave": ["palabras", "que", "siempre", "van", "en", "acento"]}
   ```
9. Escribe `elementos.json`: **una cosa a la vez**, cada una contesta lo que la gente está pensando en ese segundo, y cada una con su `sfx` (el nombre de un sonido en la carpeta `sfx/`):
   ```json
   [
     {"tipo": "dedo",     "texto": "28 NOV",  "desde": 28.7, "hasta": 31.5, "sfx": "pop"},
     {"tipo": "detras",   "texto": "CORAZÓN", "desde": 4.9,  "hasta": 7.0,  "y": 0.22},
     {"tipo": "etiqueta", "texto": "AVISO",   "desde": 0.3,  "hasta": 3.0,  "y": 0.12, "sfx": "clic"},
     {"tipo": "zoom",     "desde": 24.6, "hasta": 26.0, "escala": 1.12, "sfx": "whoosh"}
   ]
   ```
   - `dedo`: nace en la punta del índice la primera vez que lo levanta (busca desde 2.5 s antes de `desde`), lo sigue mientras está arriba y se queda donde lo dejó. Si no ve el dedo, avisa y lo pone arriba al centro.
   - `detras`: texto grande detrás de la persona (necesita `silueta.py` en ese tramo).
   - `etiqueta`: pastilla con texto; `x` y `y` son proporciones de la pantalla (0 a 1). Nada encima de la cara: arriba (`y` 0.10–0.20) o a los lados.
   - `zoom`: acercamiento suave para el énfasis.
10. **Pausa:** `python <skill>/scripts/componer.py --prueba 2.5,10,28.3` saca cuadros fijos de los momentos clave. Míralos y enséñaselos: ¿el texto toca el dedo en su primer cuadro? ¿algo tapa la cara? ¿se lee en un celular? Espera su visto bueno.
11. `python <skill>/scripts/componer.py` → `video_sin_audio.mp4` y `eventos.json`.

### O y A · Mezcla
12. Sonidos: busca en Pixabay (libres de regalías), **con permiso de la persona para descargar**, uno por tipo de cosa que aparece (clic = etiqueta, pop = fecha, golpe suave = sello, whoosh = zoom). Guárdalos en `sfx/` con el nombre que usaste en `elementos.json`. Música por el tema de su marca, no "épica": cama, no protagonista.
13. `python <skill>/scripts/mezcla.py --musica cancion.mp3 --desde 12 --sfx sfx` → **`final.mp4`**, con el volumen ya medido (−20 a −23 LUFS).

### El cierre
Si quiere cierre con su marca, que lleve **audio** y su **logo real** (pídeselo; nunca inventes uno ni uses un archivo que solo "se llame logo").

## Revisión C-O-R-T-A (antes de entregar, siempre)

- **C** — ¿algún corte a media frase? ¿inicio y final revisados?
- **O** — ¿queda algún silencio incómodo o muletilla? Volumen entre −20 y −23 LUFS.
- **R** — ¿cada cosa que nace de un gesto toca el dedo en su primer cuadro? ¿nada sobre la cara?
- **T** — ¿se leen los subtítulos a tamaño celular? ¿ninguno termina en conector?
- **A** — ¿una cosa a la vez? ¿cada una con su sonido? ¿el cierre tiene audio y su marca?

Dile qué letra **no** pudiste verificar. **No puedes oír el video:** dilo siempre y pídele que lo escuche. Cuando te diga qué letra falló y qué sintió ("la fecha no coincide con mi dedo"), créele antes que a tus números y pregúntale qué debería pasar.

## Notas

- La fuente por defecto de los subtítulos es Rubik Bold (`fuentes/`, licencia SIL OFL).
- Los scripts no usan internet salvo `verificar.py` (baja el modelo de manos una vez) y los modelos de transcripción la primera vez.
- Nada se sube a ningún lado: todo pasa en la computadora de la persona.
