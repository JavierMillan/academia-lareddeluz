# R · T · A — Compone el video: subtítulos + lo que aparece (en tu dedo, detrás de ti, etiquetas, zoom).
# uso: python componer.py [--prueba 3.2,10,15.5]
#   --prueba: solo guarda esos cuadros como prueba_XX.jpg (para revisar antes del render completo)
# Lee: corte.mp4, palabras.json, elementos.json, y si existen manos.json, mascaras/ y estilo.json
# Escribe: video_sin_audio.mp4 y eventos.json (cuándo cae cada sonido, para mezcla.py)
import json, os, sys, subprocess, pathlib
try: sys.stdout.reconfigure(encoding='utf-8')
except Exception: pass
import cv2, numpy as np
from PIL import Image, ImageDraw, ImageFont

AQUI = pathlib.Path(__file__).resolve().parent
EST = {"fuente_subtitulos": "", "fuente_titulos": "", "color_texto": "#FFFFFF", "color_acento": "#FFCB05",
       "color_etiqueta_fondo": "#FFCB05", "color_etiqueta_texto": "#111111",
       "subtitulos": {"tam": 0.085, "y": 0.70, "max_palabras": 3, "mayusculas": True, "mostrar": True},
       "clave": []}
if os.path.exists("estilo.json"):
    e = json.load(open("estilo.json", encoding="utf-8")); EST["subtitulos"].update(e.pop("subtitulos", {})); EST.update(e)
EL = json.load(open("elementos.json", encoding="utf-8")) if os.path.exists("elementos.json") else []
PAL = [tuple(p) for p in json.load(open("palabras.json", encoding="utf-8"))]
cap = cv2.VideoCapture("corte.mp4"); FPS = cap.get(cv2.CAP_PROP_FPS)
W, H = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)); N = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
MAN = json.load(open("manos.json")) if os.path.exists("manos.json") else None
hexrgb = lambda h: tuple(int(h.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))

def fuente(ruta, tam):
    for r in [ruta, AQUI / "fuentes" / "Rubik-Bold.ttf", "C:/Windows/Fonts/arialbd.ttf",
              "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"]:
        if r and os.path.exists(r): return ImageFont.truetype(str(r), int(tam))
    return ImageFont.load_default()

def sale(x): x = min(max(x, 0.0), 1.0); return 1 - (1 - x) ** 3            # entrada suave, sin rebote
def ventana(t, a, b, fin=.3, fout=.3):
    if t < a or t > b + fout: return 0.0
    if t < a + fin: return sale((t - a) / fin)
    if t > b: return 1 - sale((t - b) / fout)
    return 1.0

# ---------- texto como imagen RGBA con sombra suave ----------
def texto(txt, font, color, sombra=True, pad=24):
    bb = font.getbbox(txt); w, h = bb[2] - bb[0] + 2 * pad, bb[3] - bb[1] + 2 * pad
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if sombra:
        sh = Image.new("RGBA", (w, h), (0, 0, 0, 0)); ImageDraw.Draw(sh).text((pad - bb[0], pad - bb[1] + 4), txt, font=font, fill=(0, 0, 0, 150))
        sh = sh.resize((w // 4 or 1, h // 4 or 1)).resize((w, h)); im.alpha_composite(sh)
    d.text((pad - bb[0], pad - bb[1]), txt, font=font, fill=color + (255,)); return im

def pegar(fr, im, cx, cy, alfa=1.0, escala=1.0):
    if alfa <= 0.01: return
    if escala != 1.0: im = im.resize((max(1, int(im.width * escala)), max(1, int(im.height * escala))), Image.LANCZOS)
    x0, y0 = int(cx - im.width / 2), int(cy - im.height / 2)
    a = np.asarray(im, np.float32); x1, y1 = max(0, x0), max(0, y0); x2, y2 = min(W, x0 + im.width), min(H, y0 + im.height)
    if x2 <= x1 or y2 <= y1: return
    a = a[y1 - y0:y2 - y0, x1 - x0:x2 - x0]; m = a[..., 3:4] / 255 * alfa
    reg = fr[y1:y2, x1:x2].astype(np.float32); fr[y1:y2, x1:x2] = (reg * (1 - m) + a[..., 2::-1] * m).astype(np.uint8)

# ---------- subtítulos: bloques completos, nunca terminan en conector ----------
CONECT = {"de", "que", "y", "a", "en", "el", "la", "los", "las", "un", "una", "con", "por", "para", "mi", "tu", "su", "lo", "se", "o", "pero", "del", "al", "como"}
ST = EST["subtitulos"]; FS = fuente(EST["fuente_subtitulos"], W * ST["tam"])
bloques, cur = [], []
for k, p in enumerate(PAL):
    cur.append(p); w = p[2].lower().strip(".,;:¿?¡!…")
    fin_frase = p[2][-1:] in ".?!,;:" or (k + 1 < len(PAL) and PAL[k + 1][0] - p[1] > 0.45)
    if (len(cur) >= ST["max_palabras"] and w not in CONECT) or fin_frase or k == len(PAL) - 1:
        bloques.append(cur); cur = []
if cur: bloques.append(cur)
CLAVE = {c.lower() for c in EST["clave"]}
def subtitulo(fr, t):
    if not ST.get("mostrar", True): return
    for i, b in enumerate(bloques):
        a, z = b[0][0], (bloques[i + 1][0][0] if i + 1 < len(bloques) and bloques[i + 1][0][0] - b[-1][1] < 0.6 else b[-1][1] + 0.35)
        if a - 0.05 <= t < z:
            partes = []
            for s, e, w in b:
                txt = w.upper() if ST["mayusculas"] else w
                limpio = w.lower().strip(".,;:¿?¡!…")
                dicha = t >= s
                col = hexrgb(EST["color_acento"]) if (limpio in CLAVE or (s <= t < e + 0.15)) else hexrgb(EST["color_texto"])
                partes.append((txt, col, 1.0 if dicha else 0.45))
            imgs = [texto(p[0], FS, p[1]) for p in partes]; esp = int(W * ST["tam"] * 0.28) - 48
            total = sum(im.width for im in imgs) + esp * (len(imgs) - 1)
            if total > W * 0.92:                         # no cabe: lo reduce, nunca se sale del cuadro
                f = W * 0.92 / total; imgs = [im.resize((int(im.width * f), int(im.height * f))) for im in imgs]; esp = int(esp * f)
                total = sum(im.width for im in imgs) + esp * (len(imgs) - 1)
            x = W / 2 - total / 2; ent = sale((t - a) / 0.18)
            for im, p in zip(imgs, partes):
                pegar(fr, im, x + im.width / 2, H * ST["y"] + (1 - ent) * 12, p[2] * ent); x += im.width + esp
            return

# ---------- manos ----------
def dedo(i):
    if not MAN or i >= len(MAN["cuadros"]): return None
    um = 25 * H / 1920; pts = []
    for k in range(max(0, i - 2), min(len(MAN["cuadros"]), i + 3)):
        for h in MAN["cuadros"][k]:
            p = h["p"]
            if p[8][1] < p[6][1] - um and p[6][1] < p[5][1] and p[12][1] > p[10][1] - um * .4: pts.append(p[8])
    return tuple(np.mean(pts, axis=0)) if pts else None
def mascara(i):
    r = f"mascaras/{i:05d}.png"
    if not os.path.exists(r): return None
    return cv2.GaussianBlur(cv2.resize(cv2.imread(r, 0), (W, H)), (7, 7), 0).astype(np.float32)[..., None] / 255

# ---------- preparar elementos ----------
FT = lambda e, k: fuente(EST["fuente_titulos"] or EST["fuente_subtitulos"], W * e.get(k, 0.11))
eventos, avisos = [], []
for e in EL:
    e.setdefault("hasta", e["desde"] + 2.5); col = hexrgb(e.get("color", EST["color_acento"]))
    if e["tipo"] == "dedo":
        e["img"] = texto(e["texto"], FT(e, "tam"), col)
        # nace en el primer cuadro con el índice arriba dentro de la ventana [desde − 2.5 s, hasta]
        e["pos"], e["t0"] = None, None
        for i in range(max(0, int((e["desde"] - 2.5) * FPS)), min(N, int(e["hasta"] * FPS))):
            if dedo(i): e["t0"] = i / FPS; break
        if e["t0"] is None:
            avisos.append(f"'{e['texto']}': no vi tu índice arriba cerca de {e['desde']} s; sale arriba al centro.")
            e["t0"], e["fijo"] = e["desde"], (W / 2, H * 0.3)
    elif e["tipo"] == "detras":
        im = texto(e["texto"], FT(e, "tam") if "tam" in e else fuente(EST["fuente_titulos"] or EST["fuente_subtitulos"], W * .22), col, sombra=False)
        if im.width > W * 0.94: im = im.resize((int(W * 0.94), int(im.height * W * 0.94 / im.width)), Image.LANCZOS)   # nunca se sale del cuadro
        e["img"], e["t0"] = im, e["desde"]
    elif e["tipo"] == "etiqueta":
        f = fuente(EST["fuente_subtitulos"], W * e.get("tam", 0.045)); bb = f.getbbox(e["texto"])
        pw, ph = bb[2] - bb[0] + int(W * .06), bb[3] - bb[1] + int(W * .04)
        im = Image.new("RGBA", (pw, ph), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
        d.rounded_rectangle((0, 0, pw - 1, ph - 1), radius=ph // 2, fill=hexrgb(EST["color_etiqueta_fondo"]) + (255,))
        d.text((pw / 2 - (bb[0] + bb[2]) / 2, ph / 2 - (bb[1] + bb[3]) / 2), e["texto"], font=f, fill=hexrgb(EST["color_etiqueta_texto"]) + (255,))
        e["img"], e["t0"] = im, e["desde"]
    else:
        e["t0"] = e["desde"]
    if e.get("sfx"): eventos.append({"t": round(e["t0"], 3), "sfx": e["sfx"]})
json.dump(eventos, open("eventos.json", "w"), indent=1)

def zoom(t):
    z = 1.0
    for e in EL:
        if e["tipo"] == "zoom": z = max(z, 1 + (e.get("escala", 1.12) - 1) * ventana(t, e["desde"], e["hasta"], .25, .35))
    return z

def cuadro(fr, i):
    t = i / FPS; z = zoom(t)
    if z > 1.001:
        cw, ch = int(W / z), int(H / z); x0, y0 = (W - cw) // 2, int((H - ch) * 0.4)
        fr = cv2.resize(fr[y0:y0 + ch, x0:x0 + cw], (W, H), interpolation=cv2.INTER_LINEAR)
    m = None
    for e in EL:
        if e["tipo"] != "detras": continue
        a = ventana(t, e["t0"], e["hasta"], .4, .4)
        if a <= 0: continue
        if m is None: m = mascara(i)
        capa = fr.copy(); pegar(capa, e["img"], W / 2, H * e.get("y", 0.24), a)
        fr = (capa * (1 - m) + fr * m).astype(np.uint8) if m is not None else capa   # sin máscara, va encima
    for e in EL:
        if e["tipo"] == "dedo":
            if t < e["t0"] or t > e["hasta"] + 0.3: continue
            p = dedo(i) if "fijo" not in e else e["fijo"]
            # sigue la punta mientras el dedo está arriba; cuando lo bajas, se queda donde lo dejaste
            if p and (e.get("y0") is None or p[1] <= e["y0"] + H * 0.05):
                if e.get("y0") is None: e["y0"] = p[1]
                e["y0"] = min(e["y0"], p[1]); e["pos"] = (p[0], p[1] - e["img"].height * 0.55)
            if e.get("pos") is None: e["pos"] = e.get("fijo", (W / 2, H * .3))
            px = min(max(e["pos"][0], e["img"].width / 2 + 20), W - e["img"].width / 2 - 20)
            k = sale((t - e["t0"]) / 0.3)
            pegar(fr, e["img"], px, e["pos"][1], ventana(t, e["t0"], e["hasta"], .3, .3), 0.6 + 0.4 * k)
        elif e["tipo"] == "etiqueta":
            a = ventana(t, e["t0"], e["hasta"]); pegar(fr, e["img"], W * e.get("x", .5), H * e.get("y", .14) + (1 - a) * 14, a)
    subtitulo(fr, t)
    return fr

if "--prueba" in sys.argv:
    for j, ts in enumerate(sys.argv[sys.argv.index("--prueba") + 1].split(",")):
        i = int(float(ts) * FPS); cap.set(cv2.CAP_PROP_POS_FRAMES, i); ok, f = cap.read()
        if ok:
            # para los elementos que siguen al dedo, recorre desde su inicio para fijar la posición
            for e in EL:
                if e["tipo"] == "dedo" and e["t0"] <= i / FPS:
                    for k in range(int(e["t0"] * FPS), i + 1):
                        p = dedo(k)
                        if p and (e.get("y0") is None or p[1] <= e["y0"] + H * 0.05):
                            e["y0"] = p[1] if e.get("y0") is None else min(e["y0"], p[1]); e["pos"] = (p[0], p[1] - e["img"].height * 0.55)
            cv2.imwrite(f"prueba_{j:02d}.jpg", cuadro(f, i))
    print("cuadros de prueba listos:", ", ".join(f"prueba_{j:02d}.jpg" for j in range(len(sys.argv[sys.argv.index('--prueba') + 1].split(",")))))
else:
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", f"{FPS}", "-i", "-",
                            "-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p", "video_sin_audio.mp4"], stdin=subprocess.PIPE)
    i = 0
    while True:
        ok, f = cap.read()
        if not ok: break
        enc.stdin.write(cuadro(f, i).tobytes()); i += 1
        if i % int(FPS * 10) == 0: print(f"  {i / FPS:.0f} s…", flush=True)
    enc.stdin.close(); enc.wait(); print("video_sin_audio.mp4 listo")
for a in avisos: print("AVISO:", a)
print(f"eventos.json: {len(eventos)} sonidos para mezcla.py")
