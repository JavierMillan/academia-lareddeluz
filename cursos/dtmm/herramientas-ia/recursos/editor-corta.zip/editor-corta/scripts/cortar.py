# C · Une los bloques de tomas.json en corte.mp4 y pasa las palabras al tiempo del corte.
# uso: python cortar.py VIDEO.mp4 [tomas.json]
# Escribe: corte.mp4 y palabras.json ([inicio, fin, palabra] en el tiempo del corte)
import json, subprocess, sys
try: sys.stdout.reconfigure(encoding='utf-8')
except Exception: pass

if len(sys.argv) < 2: sys.exit("uso: python cortar.py VIDEO.mp4 [tomas.json]")
video = sys.argv[1]
tomas = json.load(open(sys.argv[2] if len(sys.argv) > 2 else "tomas.json"))
pal = json.load(open("transcripcion.json", encoding="utf-8"))["palabras"]

g, ins = [], []
for i, (a, b) in enumerate(tomas):
    d = b - a
    g.append(f"[0:v:0]trim={a}:{b},setpts=PTS-STARTPTS[v{i}]")
    g.append(f"[0:a:0]atrim={a}:{b},asetpts=PTS-STARTPTS,afade=t=in:d=0.02,afade=t=out:st={max(0, d - 0.03):.3f}:d=0.03[a{i}]")
    ins.append(f"[v{i}][a{i}]")
g.append(f"{''.join(ins)}concat=n={len(tomas)}:v=1:a=1[v][a]")
# el filtro va directo como argumento: -filter_complex_script ya no existe en ffmpeg 8+
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", video, "-filter_complex", ";".join(g),
                "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "192k", "corte.mp4"], check=True)

out, base = [], 0.0
for a, b in tomas:
    for p in pal:
        if p["s"] >= a - 0.02 and p["e"] <= b + 0.05:
            out.append([round(p["s"] - a + base, 3), round(min(p["e"], b) - a + base, 3), p["w"]])
    base += b - a
json.dump(out, open("palabras.json", "w", encoding="utf-8"), ensure_ascii=False)
print(f"corte.mp4 listo: {base:.1f} s, {len(tomas)} bloques, {len(out)} palabras")
print("Revisa con oído los empalmes y el final antes de seguir (C y O).")
