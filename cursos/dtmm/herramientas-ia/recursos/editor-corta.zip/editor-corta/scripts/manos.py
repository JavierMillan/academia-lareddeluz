# R · Rastrea las manos cuadro por cuadro y dice cuándo apuntas con el índice.
# uso: python manos.py [corte.mp4]
# Escribe: manos.json (21 puntos por mano por cuadro) y imprime los momentos en que el índice está arriba.
import json, sys, pathlib
try: sys.stdout.reconfigure(encoding='utf-8')
except Exception: pass
import cv2, mediapipe as mp
from mediapipe.tasks import python as mpt
from mediapipe.tasks.python import vision

video = sys.argv[1] if len(sys.argv) > 1 else "corte.mp4"
modelo = pathlib.Path(__file__).resolve().parent / "hand_landmarker.task"
if not modelo.exists(): sys.exit("Falta el modelo de manos: corre primero python verificar.py")
opt = vision.HandLandmarkerOptions(base_options=mpt.BaseOptions(model_asset_path=str(modelo)),
      running_mode=vision.RunningMode.VIDEO, num_hands=2, min_hand_detection_confidence=0.4, min_tracking_confidence=0.4)
det = vision.HandLandmarker.create_from_options(opt)
cap = cv2.VideoCapture(video); fps = cap.get(cv2.CAP_PROP_FPS)
W, H = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
esc = 540 / max(W, H) if max(W, H) > 540 else 1
cuadros, i = [], 0
while True:
    ok, f = cap.read()
    if not ok: break
    sm = cv2.cvtColor(cv2.resize(f, (int(W * esc), int(H * esc))), cv2.COLOR_BGR2RGB)
    r = det.detect_for_video(mp.Image(image_format=mp.ImageFormat.SRGB, data=sm), int(i * 1000 / fps))
    cuadros.append([{"lado": hd[0].category_name, "p": [[round(p.x * W, 1), round(p.y * H, 1)] for p in lm]}
                    for lm, hd in zip(r.hand_landmarks, r.handedness)])
    i += 1
json.dump({"fps": fps, "ancho": W, "alto": H, "cuadros": cuadros}, open("manos.json", "w"))

# índice arriba = punta (8) por encima de la articulación media (6) y del nudillo (5), con el dedo medio doblado
umbral = 25 * H / 1920
arriba = lambda h: h["p"][8][1] < h["p"][6][1] - umbral and h["p"][6][1] < h["p"][5][1] and h["p"][12][1] > h["p"][10][1] - umbral * .4
tramos, ini = [], None
for k, hs in enumerate(cuadros + [[]]):
    on = any(arriba(h) for h in hs)
    if on and ini is None: ini = k
    if not on and ini is not None:
        if (k - ini) / fps >= 0.3: tramos.append((ini / fps, k / fps))
        ini = None
print(f"manos.json listo ({i} cuadros). Momentos con el índice arriba (sostenidos ≥ 0.3 s):")
for a, b in tramos: print(f"  {a:6.2f} – {b:6.2f} s")
if not tramos: print("  ninguno: la R se hace con tu cara y tu voz (acercamientos, quietud).")
print("Ojo: la mano suele llegar ANTES que la palabra. Usa estos tiempos, no los de la transcripción.")
