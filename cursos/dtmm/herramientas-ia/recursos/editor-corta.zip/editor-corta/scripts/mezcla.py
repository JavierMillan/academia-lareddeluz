# O · A — Mezcla tu voz + música + un sonido por cada cosa que aparece, y deja el volumen listo para redes.
# uso: python mezcla.py [--musica cancion.mp3] [--desde 12] [--sfx carpeta_sfx]
#   --sfx: carpeta con los sonidos que nombras en elementos.json (p. ej. "pop" → pop.mp3)
# Lee: corte.mp4, video_sin_audio.mp4, eventos.json
# Escribe: final.mp4 (y te dice el volumen medido: debe quedar entre -20 y -23 LUFS)
import json, os, re, subprocess, sys
try: sys.stdout.reconfigure(encoding='utf-8')
except Exception: pass
import numpy as np

SR = 48000
a = sys.argv[1:]
musica = a[a.index("--musica") + 1] if "--musica" in a else None
desde = float(a[a.index("--desde") + 1]) if "--desde" in a else 0
carpeta = a[a.index("--sfx") + 1] if "--sfx" in a else "sfx"

def leer(p, ss=0, dur=None):
    cmd = ["ffmpeg", "-v", "error", "-ss", str(ss)] + (["-t", str(dur)] if dur else []) + ["-i", p, "-ac", "2", "-ar", str(SR), "-f", "f32le", "-"]
    return np.frombuffer(subprocess.run(cmd, capture_output=True).stdout, np.float32).reshape(-1, 2).copy()
def son(x, activa=False):                    # sonoridad en ventanas de 400 ms: los picos mienten sobre el volumen
    w, h = int(.4 * SR), int((.05 if activa else .1) * SR); m = x.mean(axis=1)
    if len(m) <= w: return 10 * np.log10(np.mean(m ** 2) + 1e-12)
    v = [10 * np.log10(np.mean(m[i:i + w] ** 2) + 1e-12) for i in range(0, len(m) - w, h)]
    return float(max(v) if activa else np.median(v))
nivel = lambda x, obj, act=False: x * 10 ** ((obj - son(x, act)) / 20)

voz = leer("corte.mp4"); N = len(voz); dur = N / SR
VOZ = son(voz)
mix = voz.copy()
if musica:
    mus = leer(musica, desde, dur + 1)[:N]
    mus = nivel(mus, VOZ - 18)                              # cama: bastante abajo de tu voz
    t = np.arange(len(mus)) / SR
    g = np.clip(t / 1.5, 0, 1) * (1 - np.clip((t - (dur - 2)) / 2, 0, 1))
    mix[:len(mus)] += mus * g[:, None]
eventos = json.load(open("eventos.json")) if os.path.exists("eventos.json") else []
faltan = set()
for ev in eventos:
    nom = ev["sfx"]; ruta = next((os.path.join(carpeta, nom + ext) for ext in ("", ".mp3", ".wav") if os.path.isfile(os.path.join(carpeta, nom + ext))), None)
    if not ruta: faltan.add(nom); continue
    x = leer(ruta, 0, 2.5); x[-int(.05 * SR):] *= np.linspace(1, 0, int(.05 * SR))[:, None]
    x = nivel(x, VOZ - 6, True); x *= min(1.0, .45 / (np.abs(x).max() + 1e-9))
    k = int(ev["t"] * SR); mix[k:k + len(x)] += x[:max(0, N - k)]

def lufs(arr):
    arr.astype(np.float32).tofile("_mezcla.f32")
    out = subprocess.run(["ffmpeg", "-hide_banner", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "_mezcla.f32", "-af", "ebur128=framelog=quiet", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    I = float(re.findall(r"I:\s+(-?[\d.]+) LUFS", out)[-1]); LRA = float(re.findall(r"LRA:\s+(-?[\d.]+) LU", out)[-1]); return I, LRA
I, _ = lufs(mix); mix *= 10 ** ((-21 - I) / 20)
mix = np.where(np.abs(mix) > .85, np.sign(mix) * (.85 + .12 * np.tanh((np.abs(mix) - .85) / .12)), mix)   # limitador suave
I, LRA = lufs(mix)
subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(SR), "-ac", "2", "-i", "_mezcla.f32", "mezcla.wav"], check=True)
os.remove("_mezcla.f32")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", "video_sin_audio.mp4", "-i", "mezcla.wav", "-map", "0:v", "-map", "1:a",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", "final.mp4"], check=True)
print(f"final.mp4 listo · volumen {I:.1f} LUFS (objetivo -20 a -23) · rango {LRA:.1f} LU")
if faltan: print("AVISO: no encontré estos sonidos en", carpeta + ":", ", ".join(sorted(faltan)))
print("Claude no puede oír: escúchalo tú y di qué letra falló si algo no suena bien (O o A).")
