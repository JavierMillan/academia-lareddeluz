# R · Recorta tu silueta solo en los tramos que llevan texto detrás de ti (es lento: no lo corras en todo el video).
# uso: python silueta.py INICIO-FIN [INICIO-FIN ...]   p. ej.  python silueta.py 12.5-16 40-44.2
# Escribe: mascaras/00012.png … (una por cuadro, a media resolución)
import sys, os
try: sys.stdout.reconfigure(encoding='utf-8')
except Exception: pass
import cv2
from PIL import Image
from rembg import new_session, remove

if len(sys.argv) < 2: sys.exit("uso: python silueta.py INICIO-FIN [INICIO-FIN ...]")
R = [tuple(map(float, x.split("-"))) for x in sys.argv[1:]]
os.makedirs("mascaras", exist_ok=True)
S = new_session("u2net_human_seg")
cap = cv2.VideoCapture("corte.mp4"); fps = cap.get(cv2.CAP_PROP_FPS); i = n = 0
while True:
    ok, f = cap.read()
    if not ok: break
    t = i / fps
    if any(a <= t <= b for a, b in R):
        h, w = f.shape[:2]; sm = cv2.resize(f, (w // 2, h // 2))
        remove(Image.fromarray(cv2.cvtColor(sm, cv2.COLOR_BGR2RGB)), session=S, only_mask=True).save(f"mascaras/{i:05d}.png"); n += 1
    i += 1
print(f"{n} máscaras listas en mascaras/")
