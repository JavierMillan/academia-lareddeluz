# C · O · T — Transcribe el video palabra por palabra y propone los cortes.
# uso: python transcribir.py VIDEO.mp4 [--modelo small|medium|large-v3] [--idioma es]
# Escribe: transcripcion.json (palabras con tiempos), transcripcion.txt (para leer)
#          y tomas.json (propuesta de bloques: quita el inicio vacío, el final, pausas > 0.6 s y muletillas).
import json, subprocess, sys, tempfile, os
try: sys.stdout.reconfigure(encoding='utf-8')
except Exception: pass

args = sys.argv[1:]
if not args: sys.exit("uso: python transcribir.py VIDEO.mp4 [--modelo small] [--idioma es]")
video = args[0]
modelo = args[args.index("--modelo") + 1] if "--modelo" in args else "small"
idioma = args[args.index("--idioma") + 1] if "--idioma" in args else "es"
PAUSA, RESPIRO = 0.6, 0.25
MULETILLAS = {"este", "eh", "em", "mmm", "ehm", "ah", "eeh", "esteee"}

wav = os.path.join(tempfile.gettempdir(), "editor_corta_audio.wav")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", video, "-vn", "-ac", "1", "-ar", "16000", wav], check=True)
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video],
                           capture_output=True, text=True).stdout.strip())

from faster_whisper import WhisperModel
try:
    m = WhisperModel(modelo, device="cuda", compute_type="float16")
    next(iter(m.transcribe(wav, language=idioma, beam_size=1)[0]), None)   # prueba real: falla aquí si la GPU no sirve
    print("Transcribiendo en GPU…")
except Exception:
    m = WhisperModel(modelo, device="cpu", compute_type="int8"); print("Transcribiendo en CPU (puede tardar)…")
segs, _ = m.transcribe(wav, language=idioma, word_timestamps=True, vad_filter=False)
pal = []
for s in segs:
    for w in s.words:
        if w.end - w.start <= 0.01: continue          # Whisper inventa palabras de duración cero en los silencios
        pal.append({"w": w.word.strip(), "s": round(w.start, 3), "e": round(w.end, 3)})
json.dump({"video": video, "duracion": dur, "palabras": pal}, open("transcripcion.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# texto legible con tiempos: una línea nueva en cada pausa
with open("transcripcion.txt", "w", encoding="utf-8") as f:
    linea, t0 = [], None
    for k, p in enumerate(pal):
        if t0 is None: t0 = p["s"]
        linea.append(p["w"])
        if p["w"][-1:] in ".?!" or k + 1 == len(pal) or pal[k + 1]["s"] - p["e"] > 0.35 or len(linea) >= 16:
            f.write(f"[{t0:7.2f}] {' '.join(linea)}\n"); linea, t0 = [], None

# silencios reales por ENERGÍA del audio (Whisper estira las palabras sobre las pausas y no las ve)
import numpy as np
au = np.fromfile(wav, dtype=np.int16, offset=44).astype(np.float32) / 32768
hop = 160                                                        # 10 ms a 16 kHz
rms = np.array([np.sqrt(np.mean(au[i:i + 320] ** 2) + 1e-12) for i in range(0, len(au) - 320, hop)])
db = 20 * np.log10(rms + 1e-9)
voz_db = np.percentile(db, 90); piso = np.percentile(db[db > -90], 10) if (db > -90).any() else -60
umbral = max(piso + 10, voz_db - 30)                             # silencio = cerca del piso de la sala
sil, ini = [], None
for i, v in enumerate(np.append(db, 0)):
    if v < umbral and ini is None: ini = i
    if v >= umbral and ini is not None:
        if (i - ini) * .01 > PAUSA: sil.append((ini * .01, i * .01))
        ini = None
limpio = lambda w: w.lower().strip(".,;:¿?¡!…\"'")
# pausas cortas (> 0.25 s) para reconocer una muletilla: "este" solo lo es si va pegado a una pausa
# ("no… este… chicos"); en "este video" es palabra normal y se queda
cortas, ini = [], None
for i, v in enumerate(np.append(db, 0)):
    if v < umbral and ini is None: ini = i
    if v >= umbral and ini is not None:
        if (i - ini) * .01 > 0.25: cortas.append((ini * .01, i * .01))
        ini = None
# (Whisper a veces "estira" la muletilla sobre la pausa: si la palabra se encima con una pausa, también cuenta)
junto_a_pausa = lambda p: any(abs(p["s"] - b) < 0.2 or abs(p["e"] - a) < 0.2 or min(p["e"], b) - max(p["s"], a) > 0.2 for a, b in cortas)
SIEMPRE = MULETILLAS - {"este"}
quitadas = [p for p in pal if limpio(p["w"]) in SIEMPRE or (limpio(p["w"]) == "este" and junto_a_pausa(p))]
voz_ini = next((b for a, b in sil if a <= 0.05), 0.0)  # si el video empieza en silencio, arranca donde empieza la voz
voz_fin = next((a for a, b in sil if b >= dur - 0.05), dur)
quitar = [(a + RESPIRO / 2, b - RESPIRO / 2) for a, b in sil if a > voz_ini and b < voz_fin]
for q in quitadas: quitar.append((q["s"] - 0.05, q["e"] + 0.08))
quitar.sort()
ini, fin = max(0, voz_ini - RESPIRO), min(dur, voz_fin + 0.4)
tomas, a = [], ini
for x, y in quitar:
    if x > a + 0.15: tomas.append([round(a, 2), round(x, 2)])
    a = max(a, y)
if fin > a + 0.15: tomas.append([round(a, 2), round(fin, 2)])
# junta bloques casi pegados (cortes que no se notarían)
junt = []
for t in tomas:
    if junt and t[0] - junt[-1][1] < 0.12: junt[-1][1] = t[1]
    else: junt.append(t)
json.dump(junt, open("tomas.json", "w"), indent=1)
print(f"Pausas largas (> {PAUSA} s): " + ", ".join(f"{a:.1f}–{b:.1f}" for a, b in sil) if sil else "Sin pausas largas.")

total = sum(b - a for a, b in junt)
print(f"\nListo: {len(pal)} palabras · video {dur:.1f} s → propuesta {total:.1f} s en {len(junt)} bloques")
print(f"Muletillas encontradas: {len(quitadas)} · revisa transcripcion.txt y tomas.json antes de cortar.")
print("Ojo: revisa el FINAL. Si al final hay una frase colgada o te despides, recorta la última toma.")
