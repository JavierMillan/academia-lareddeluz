# Revisa que estén las herramientas de Editor CORTA y baja el modelo de manos si falta.
# uso: python verificar.py
import importlib, shutil, subprocess, sys, urllib.request, pathlib
try: sys.stdout.reconfigure(encoding='utf-8')
except Exception: pass

AQUI = pathlib.Path(__file__).resolve().parent
MODELO = AQUI / "hand_landmarker.task"
URL = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task"
ok = True

def linea(nombre, bien, nota=""):
    print(("  [OK] " if bien else "  [FALTA] ") + nombre + (f" — {nota}" if nota else ""))

print("Editor CORTA · revisión de herramientas\n")
v = sys.version_info
linea(f"Python {v.major}.{v.minor}", v >= (3, 10), "" if v >= (3, 10) else "necesitas Python 3.10 o más nuevo")
ok &= v >= (3, 10)

ff = shutil.which("ffmpeg")
linea("ffmpeg", bool(ff), "corta y exporta el video" if ff else "instálalo (Windows: winget install Gyan.FFmpeg · Mac: brew install ffmpeg)")
ok &= bool(ff)

for mod, pip, para in [("faster_whisper", "faster-whisper", "C · O · T  transcribe palabra por palabra"),
                       ("cv2", "opencv-python", "lee y escribe cuadros"),
                       ("PIL", "pillow", "dibuja textos"),
                       ("numpy", "numpy", "cálculos"),
                       ("mediapipe", "mediapipe", "R  rastrea tus manos"),
                       ("rembg", "rembg[cpu]", "R  recorta tu silueta (opcional)")]:
    try:
        importlib.import_module(mod); linea(pip, True, para)
    except Exception:
        linea(pip, False, f"pip install {pip}  ({para})")
        if mod != "rembg": ok = False

if not MODELO.exists():
    try:
        print("\n  Bajando el modelo de manos de MediaPipe (7 MB)…")
        urllib.request.urlretrieve(URL, MODELO)
    except Exception as e:
        print("  No se pudo bajar:", e)
linea("modelo de manos", MODELO.exists(), str(MODELO) if MODELO.exists() else URL)
ok &= MODELO.exists()

print("\n" + ("Todo listo." if ok else "Falta algo: instala lo que dice [FALTA] y vuelve a correr este archivo."))
sys.exit(0 if ok else 1)
