# Brand Profile — schema & filled example

The Brand Profile is Prism's single source of truth for a project. It is a
markdown file, `brand-profile-<slug>.md`, read at the start of every Compose and
Tune, and written/updated by Forge.

Rules for a good Profile:

- **Concrete over adjective.** Every visual section ends in usable values: hex
  codes, real font names, a scale ratio, spacing units, percentages. "Modern and
  clean" is not a spec; `Inter / 1.250 scale / 8px grid / #0E1116` is.
- **Trace to essence.** Each visual rule should be explainable from the brand's
  personality. If you can't explain *why*, it's decoration, not identity.
- **Mark inference.** Anything not confirmed by the user gets `(inferido —
  confirmar)` so it's easy to revise. Anything confirmed loses the tag.
- **Living.** When a design decision exposes a missing/wrong rule, update the
  file. Bump the version line.

---

## SCHEMA (copy this structure)

```markdown
# Brand Profile — <Brand Name>
<!-- version: 0.1 · updated: YYYY-MM-DD · status: draft|confirmed -->

## 0. Snapshot
- One-line definition: <what it is, for whom>
- Tagline / phrase: <if any>
- Primary channel(s): <web, IG, print…>
- Conversion / goal of most visuals: <inform | sell | move | brand>

## 1. Essence (the source of the light)
- Mission / promise:
- Personality (3-5 adjectives):
- Jungian archetype (+ shadow):
- Audience (who, and their internal state):
- The ONE feeling every visual must evoke:
- Brands/works admired (direction, never to copy):

## 2. Color system
- Role-based palette (the 60-30-10 backbone):
  - Dominant / base (~60%): <name> `#hex` — usage
  - Secondary (~30%): <name> `#hex` — usage
  - Accent (~10%, reserved for what must pop): <name> `#hex` — usage
- Neutrals: ink `#hex`, paper `#hex`, muted `#hex`, line `#hex`
- Harmony logic: <complementary | analogous | triadic | mono…> and why it fits essence
- Semantic (UI only): success `#hex` · warning `#hex` · error `#hex` · info `#hex`
- Light / dark mode pairs (if relevant)
- Verified contrast pairs: <ink on paper = X:1 (AA/AAA), accent on base = X:1…>

## 3. Typography system
- Heading face: <font> — weights used; where to get it
- Body face: <font> — weights used
- (Optional) mono/accent face:
- Pairing rationale (← essence):
- Type scale: base <16px> · ratio <1.250 Major Third> → steps: 12·14·16·20·25·31·39…
- Defaults: body leading <1.5> · heading leading <1.1-1.25> · tracking rules ·
  max line length <60-75 char>
- Text alignment policy: <left default; centered only for short display>

## 4. Composition & layout doctrine
- Grid: <12-col web | 8px spacing base | columns/margins/gutter>
- Spacing scale: <4·8·12·16·24·32·48·64>
- Balance bias: <asymmetric/editorial | symmetric/formal | radial>
- Focal-point strategy: <how the hero element is made to dominate>
- Negative space stance: <generous | dense-editorial>
- Signature moves: <e.g. oversized headline + small caption; full-bleed image + corner lockup>
- Aspect-ratio defaults per channel: <IG post 4:5, story 9:16, web hero 16:9…>

## 5. Dirección de estilo
- Señales leídas (una línea cada una): paleta · logo/tipo · persona · contexto
- Mezcla aprobada: <e.g. 60% escandinavo / 30% editorial / 10% déco>
- Por qué (señales que la sostienen) y tensión, si la hay:
- Por corriente de la mezcla (resumen investigado, aplicado a ESTA marca):
  - Porqué del estilo:
  - Layout · tipografía · color · textura · movimiento · voz:
  - Gestos que tomamos / prohibidos:
  - Referencias reales (links):
- Texture / finish: <flat | grain | paper | metal | CRT…>
- Shape language: <rounded | sharp | geometric | organic>; corner radius <px>

## 5b. Códigos de marca (5-7)
Por código: qué es · regla exacta · cómo vive en web / carrusel / video · qué NO es.
1. <código>
2. <código>
3. <código>

## 5c. Firma de movimiento
- Carácter: <lento y suave | preciso | seco | elástico | orgánico>
- Easing y duraciones: <cubic-bezier(...)> · micro <ms> · entrada <ms> · escena <s>
- Gesto de revelación: <se dibuja | se enfoca | corte seco | se pinta…>
- Transición entre escenas:
- Mecánica web por defecto: <secciones con transiciones | scroll atado | híbrido>
- Sonido (video):

## 6. Imagery direction
- Medium: <photography | illustration | 3D | mixed>
- Treatment: <color grade, contrast, mood, lighting>
- Subject do / don't:
- For AI generation: recurring prompt anchors + negative anchors

## 7. Logo & assets
- Logo files / lockups:
- Clear space + min size:
- Do / don't (no recolor, no stretch, no busy backgrounds…):

## 8. Voice tie-in (so visual matches verbal)
- Tone in 3 words:
- How tone shows up visually:

## 9. Guardrails — the "never" list
- <never use pure black #000>
- <never more than one accent per composition>
- <never center long body text>
- <…>

## 10. Reglas aprendidas (de correcciones del usuario)
- YYYY-MM-DD · <pieza> · <qué se corrigió> → <regla nueva>
```

---

## FILLED EXAMPLE (illustrative — a fictional brand, to show the level of specificity)

```markdown
# Brand Profile — Cerro (specialty coffee, fictional)
<!-- version: 1.0 · updated: 2026-06-25 · status: confirmed -->

## 0. Snapshot
- One-line definition: single-origin specialty coffee for curious home brewers.
- Tagline: "Altura en cada taza."
- Primary channels: Instagram + e-commerce web + bag packaging.
- Goal of most visuals: brand + sell (product-aware audience).

## 1. Essence
- Mission: make origin-grade coffee approachable without dumbing it down.
- Personality: grounded, precise, warm, quietly premium, curious.
- Archetype: Explorer (shadow: elitism — must stay welcoming, never snobby).
- Audience: 25-45, design-literate, values craft; mild fear of "doing it wrong".
- ONE feeling: calm confidence — "I'm in good, expert hands."
- Admired: Aesop (restraint), Monocle (editorial), Stumptown (craft honesty).

## 2. Color system
- Dominant (~60%): Bone `#F4EFE6` — backgrounds, paper.
- Secondary (~30%): Espresso `#2B211A` — ink, large type, footers.
- Accent (~10%): Clay `#C2603A` — CTAs, single highlight per composition.
- Neutrals: line `#DAD2C4`, muted text `#6E6358`.
- Harmony: warm analogous (browns→terracotta) ← grounded/earthy essence; the
  clay accent is the one warm "spark" of curiosity.
- Semantic (web): success `#5B7A52` · error `#A23B2C` · info `#3A5A6E`.
- Contrast: Espresso on Bone = 11.8:1 (AAA); Clay on Bone = 4.6:1 (AA, large/CTA
  only — never small body text).

## 3. Typography
- Heading: "Fraunces" (display serif), 400/600 — characterful, editorial warmth.
- Body: "Inter", 400/500 — neutral, highly legible on screen.
- Rationale: serif heading = craft/heritage; clean sans body = approachability.
- Scale: base 16px · ratio 1.250 → 12·14·16·20·25·31·39·49.
- Defaults: body leading 1.55 · headings 1.1 · body line length 60-72 char.
- Alignment: left default; center only for ≤5-word display lines.

## 4. Composition & layout doctrine
- Grid: 12-col web, 8px spacing base; generous margins (min 24px mobile).
- Spacing scale: 4·8·12·16·24·32·48·64·96.
- Balance: asymmetric/editorial — content weighted to a strong left column.
- Focal strategy: one full-bleed product/origin photo + small type lockup in a
  corner third; scale jump between headline and caption is dramatic (≈3×).
- Negative space: generous — emptiness signals premium calm.
- Signature move: oversized Fraunces headline over wide bone space, tiny clay
  caption as the only color.
- Aspect ratios: IG 4:5, story 9:16, web hero 16:9, bag panel 2:3.

## 5. Dirección de estilo
- Señales: paleta tierra apagada · wordmark serif con carácter · voz experta y cálida · sector lleno de kraft y pizarras.
- Mezcla: 65% minimalismo premium / 25% editorial cálido / 10% artesanal.
- Por qué: la calma experta pide espacio (minimalismo); la curiosidad pide relato (editorial); el origen pide mano (artesanal). Tensión: premium sin esnobismo.
- Texture: subtle paper grain on backgrounds; matte, never glossy.
- Shape: soft-geometric; corner radius 4px (restrained).

## 5b. Códigos de marca
1. **La cota de altura** — cada pieza lleva la altitud del origen (`1 850 msnm`) en versalitas pequeñas, siempre en la esquina inferior izquierda. Web: en cada sección. Carrusel: en cada slide. Video: aparece al primer corte. Siempre es un dato real, nunca decoración.
2. **Una sola chispa de Clay** — el acento aparece una vez por pieza y toca lo que se hace con las manos (vertido, molienda). Nunca en fondos ni en texto largo.
3. **El vapor como transición** — las escenas cambian con un fundido lento que sube, como vapor. Nunca cortes secos.
4. **Titular que respira** — titular Fraunces enorme con ≥40% de espacio vacío alrededor.
5. **Grano de papel** en todo fondo claro.

## 5c. Firma de movimiento
- Carácter: lento y suave. Easing `cubic-bezier(.22,1,.36,1)` · micro 200 ms · entrada 700 ms · escena 1.4 s.
- Revelación: se enfoca desde un desenfoque leve mientras sube 12 px.
- Mecánica web: secciones con transiciones de estado; nada atado al scroll.

## 6. Imagery
- Medium: photography first; line-illustration for process diagrams.
- Treatment: warm natural light, soft shadows, slightly desaturated, never HDR.
- Do: hands, steam, origin landscapes, single product on bone. Don't: stock
  "business" imagery, cool blue grades, cluttered flat-lays.
- AI anchors: "warm soft daylight, matte film grain, shallow depth, earthy
  palette"; negative: "neon, glossy, HDR, busy background".

## 7. Logo & assets
- Wordmark in Fraunces; mountain mark for avatars.
- Clear space = cap-height all sides; min wordmark width 96px.
- Don't: recolor outside palette, stretch, place on busy photo without scrim.

## 8. Voice tie-in
- Tone: knowledgeable, calm, generous.
- Visually: lots of room to breathe, precise alignment, one idea per frame.

## 9. Guardrails — never
- Never pure black (#000) — use Espresso.
- Never more than one Clay accent element per composition.
- Never center long body text.
- Never glossy/HDR imagery.
- Never more than two type families.
```

When filling a real Profile, match this density. Empty or vague fields make the
whole system weaker — every later output inherits the precision (or the fog) of
the Profile.
