# Códigos de marca y filtro anti-default

## Qué es un código

Un elemento **propio** que se repite en todo formato hasta que la gente reconoce
la marca sin ver el logo (el swoosh y la tipografía condensada de Nike; el
espacio en blanco y la revelación lenta de Apple). Un color solo casi nunca
basta; un código es una forma de **usar** algo.

## Cómo derivarlos

Cruza la **esencia** (en qué cree, su tensión, su emoción) con la **dirección de
estilo** aprobada. Busca 5-7 códigos repartidos en estas familias (no todas son
obligatorias):

| Familia | Pregunta | Ejemplo de forma |
|---|---|---|
| Forma / marca gráfica | ¿qué figura solo usamos nosotros? | un destello de 4 puntas exacto; un marco escalonado |
| Gesto de movimiento | ¿cómo entra o se revela todo? | la línea que se dibuja; el corte seco; el fundido lento con grano |
| Recurso de layout | ¿qué estructura se repite? | retícula expuesta; titular que sangra fuera del borde; coordenada en esquina |
| Tratamiento tipográfico | ¿qué hacemos con las letras que nadie hace? | mezcla serif itálica + mono en el mismo titular |
| Momento de color | ¿cuándo y dónde aparece el acento? | el acento solo toca lo humano; el color entra una vez por pieza |
| Textura / material | ¿de qué está hecho el mundo? | papel, grano, tinta, metal, pantalla CRT |
| Sonido / voz | ¿cómo suena y cómo habla? | un tono al encender; frases cortas en segunda persona |

Cada código se escribe con: **qué es · regla exacta · cómo vive en web / carrusel / video · qué NO es**.

Prueba de propiedad: si otra marca del mismo estilo podría usarlo igual, todavía
no es un código; afílalo con la esencia.

## Lista anti-default (prohibido salvo razón explícita)

- Héroe centrado con titular + subtítulo + dos botones sobre degradado.
- Degradados morado/azul/rosa "IA", orbes o blobs brillando.
- Glassmorphism y tarjetas translúcidas por inercia.
- Tres (o cuatro) columnas de tarjetas con ícono + título + texto.
- Emojis como íconos; íconos de línea genéricos para todo.
- Inter / Roboto / Poppins como única voz tipográfica sin tensión.
- Partículas flotando sin significado; "brillos" repartidos por todo.
- Sombras suaves genéricas y radios de borde iguales en todo.
- Animación de "fade-up" idéntica en cada bloque.
- Metáforas visuales literales y gastadas (foco = idea, cohete = crecimiento, apretón de manos = alianza).
- Fotos de stock de gente sonriendo frente a una laptop.

## Pruebas

- **Tapa el logo:** ¿se reconoce la marca en un segundo? Cuenta los códigos presentes (mínimo 3).
- **Prueba ciega de estilo:** mostrar piezas sin nombre; quien conoce la corriente debe reconocerla.
- **Prueba de intercambio:** si le pones el logo de un competidor y funciona igual, la pieza es genérica.
