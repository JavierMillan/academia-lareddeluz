# Color

Color carries mood, hierarchy, and brand recognition before a single word is
read. The goal is a small, disciplined system where every color has a job.

## The three properties

- **Hue** — the color itself (red, blue…), position on the wheel.
- **Saturation / chroma** — intensity, from vivid to gray. High saturation grabs
  attention and reads energetic/cheap-if-overused; muted reads sophisticated/calm.
- **Value / lightness** — how light or dark. **Value does most of the heavy
  lifting** for hierarchy and legibility — a design usually works in grayscale
  first or not at all. Check your value structure by desaturating it.

Warm hues (red→yellow) advance, feel energetic/cozy; cool hues (green→blue)
recede, feel calm/trustworthy. Temperature contrast creates depth and focus.

## Harmonies (relationships on the wheel)

Pick the relationship that fits the brand's essence; don't collect colors at
random.

- **Monochromatic** — one hue, varied in value/saturation. Cohesive, elegant,
  easy; risk: flat. Add a wide value range for interest.
- **Analogous** — neighbors on the wheel (e.g. yellow-orange-red). Harmonious,
  natural, comfortable; pick one to dominate and use the others as support.
- **Complementary** — opposites (blue/orange, red/green). Maximum vibrance and
  contrast; great for a focal accent against a base. Don't use 50/50 at full
  saturation — they vibrate; let one dominate and the other accent.
- **Split-complementary** — a base plus the two neighbors of its complement.
  High contrast with less tension than pure complementary; very usable.
- **Triadic** — three evenly spaced hues. Vibrant and balanced; let one lead,
  the other two support.
- **Tetradic / square** — two complementary pairs. Rich but hard; needs one
  dominant hue and careful balance, or it gets noisy.

## Building a usable palette: 60-30-10

A reliable structure for almost anything:

- **60% dominant** — usually a neutral or desaturated brand color; backgrounds,
  large fields. Sets the overall feel.
- **30% secondary** — supports and structures; secondary surfaces, large type.
- **10% accent** — the loudest, most saturated color, *reserved* for what must
  pop: the CTA, the one highlight, the subject. Scarcity is what gives the accent
  its power; spend it everywhere and nothing pops.

Then add a **neutral set** outside the ratio: a near-black ink (rarely pure
`#000`), a paper/background, one or two grays, a hairline color. Neutrals are
where most of a real interface or layout actually lives.

For UI also define **semantic colors**: success (green), warning (amber), error
(red), info (blue) — and their accessible text-on-color pairs. And **state**
variants (hover/active/disabled) derived by shifting value, not random new hues.

## Contrast & accessibility (a floor, not a nicety)

- Text contrast targets (WCAG): **4.5:1** for normal text, **3:1** for large text
  (~24px+ or 19px+ bold) and meaningful UI/graphics, at AA. AAA wants **7:1**.
  Low-contrast gray-on-white text is the single most common amateur mistake —
  fix it first.
- **Never rely on color alone** to convey meaning (e.g. red/green status). Add an
  icon, label, or shape — ~1 in 12 men have a color-vision deficiency.
- Test pairings, don't eyeball them; state computed ratios in the Brand Profile.
- Saturated text on saturated background is hard to read even at "passing"
  ratios — prefer high *value* difference.

## Light & dark modes

- Dark mode isn't just inverted. Use a dark gray base (e.g. `#121316`), not pure
  black, to reduce halation; desaturate/raise lightness of accents so they don't
  glow harshly; reduce large pure-white areas.
- Keep the same hue *identity* across modes; adjust value/saturation so contrast
  targets still pass in both.

## Color psychology (use as a prior, not a law)

Associations are real but culture- and context-dependent — verify against the
audience, don't apply mechanically:

- **Red** — energy, urgency, appetite, danger, passion.
- **Orange** — warmth, friendliness, affordable energy, playfulness.
- **Yellow** — optimism, attention, caution; tiring in large saturated doses.
- **Green** — growth, nature, health, money, "go"; calming.
- **Blue** — trust, calm, competence, corporate; can feel cold/distant.
- **Purple** — luxury, creativity, spirituality, mystery.
- **Pink** — playful to romantic to bold, depending on shade.
- **Brown / earth** — grounded, natural, craft, heritage.
- **Black** — luxury, power, sophistication, or severity.
- **White** — clean, simple, spacious, premium (via restraint).

Context overrides the list: a "trustworthy blue" in a craft-bakery brand may read
cold and wrong. Always reconcile psychology with the brand's essence and category.

## Common color mistakes

- Too many hues with no dominant one (noise).
- Accent used everywhere (nothing pops).
- Pure black/`#000` and pure saturated fills for large areas (harsh, cheap).
- Color carrying meaning with no backup label/icon.
- Failing text contrast for "aesthetic" light grays.
- Vibrating complementaries at equal weight/saturation.
