# Composition & Layout

How elements are arranged in space. Composition decides what the eye sees, in
what order, and how the whole feels. Everything here serves two jobs: a clear
**focal point** and a deliberate **reading path**.

## Start with hierarchy, not decoration

Before placing anything, decide the order of importance: what is seen 1st, 2nd,
3rd. The tools that create that order:

- **Size / scale** — bigger reads as more important. Use *dramatic* jumps (a
  headline 3-4× the caption), not timid ones. Everything mid-sized = monotony.
- **Contrast** — a high-contrast element on a quiet field wins attention. (See
  `color.md` and the contrast notes below.)
- **Position** — top and left get seen first in LTR cultures; optical center
  (slightly above true center) is the strongest single spot.
- **Isolation** — surround an element with empty space and it becomes the focus.
- **Color** — a single saturated accent in a muted field pulls the eye.
- **Direction** — lines, gazes, and arrows point attention.

The **squint test**: blur the design; the focal point must still dominate and the
structure must still read. If it turns to mush, hierarchy/contrast is too weak.

## Placement systems

- **Rule of thirds** — divide the frame into a 3×3 grid; place focal elements on
  the lines or at their intersections rather than dead-center. Creates natural
  tension and balance; the default for photography and most layouts.
- **Golden ratio (≈1.618) / Fibonacci spiral** — proportion and placement that
  feel organically pleasing; use the spiral to position a focal point and let
  secondary elements trail along the curve. Also drives pleasing size
  relationships (a layout split ~62/38).
- **Dead center** — maximal stability and confrontation; powerful for single-
  subject, symmetrical, formal compositions — but only *on purpose*. Accidental
  centering is the most common amateur layout.
- **Optical adjustments** — true mathematical center looks slightly low; nudge
  focal elements up. Round shapes need to overshoot edges to look aligned with
  square ones.

## Balance — distributing visual weight

Weight comes from size, darkness, color saturation, density, and isolation.

- **Symmetrical** — mirror weight across an axis. Reads stable, formal, calm,
  trustworthy, classic. Risks being static/boring.
- **Asymmetrical** — different elements of equal *weight* balance across the
  composition (a large pale shape vs. a small dark one). Reads dynamic, modern,
  editorial. The harder skill; the more interesting result.
- **Radial** — elements arranged around a central point; energetic, focusing.
- A small, high-contrast or isolated element carries surprising weight — use it
  to counter a large quiet mass.

## The grid — what separates intentional from floating

- Choose a structure: columns (classic 12-col for web), modular grids (cards),
  or a baseline grid for type rhythm.
- Define **margins, columns, gutters** and keep to them. Consistency here is most
  of what makes work look "designed."
- A **spacing scale** (e.g. 4·8·12·16·24·32·48·64) keeps gaps consistent and
  rhythmic. Random spacing is a top amateur tell.
- **Alignment**: every element shares an edge or centerline with another. When in
  doubt, left-align and reduce the number of distinct alignment lines.
- Breaking the grid (an element that bleeds or overlaps) creates emphasis —
  strong when deliberate, weak when accidental.

## Negative (white) space — an active material

- Space is not waste; it gives the eye rest, separates groups (Gestalt
  proximity), and makes the focal point breathe.
- **Macro** space (margins, gaps between sections) sets the overall calm/premium
  feel; **micro** space (between lines, letters, list items) drives legibility.
- Crowding reads as cheap and anxious; restraint reads as premium and confident.
  When a layout feels off and you can't say why, it usually needs *more* space,
  not more stuff.

## Leading the eye (visual flow)

- **Z-pattern** — for sparse layouts (posters, landing heroes): eye sweeps
  top-left → top-right → diagonal → bottom-left → bottom-right. Put logo top-left,
  key action bottom-right.
- **F-pattern** — for text-dense pages: readers scan across the top, then down
  the left, with shorter horizontal glances. Front-load meaning on the left.
- **Leading lines** — roads, edges, limbs, implied lines aim the eye at the
  subject.
- **Gaze direction** — viewers look where depicted faces/bodies look; point them
  at the message, not off-frame.
- **Size & contrast gradients** — the eye travels from large/high-contrast to
  small/low-contrast; sequence elements accordingly.

## Depth (especially images & illustration)

- **Foreground / midground / background** layering creates space and a place for
  the subject.
- **Overlap** (one shape in front of another) is the simplest depth cue.
- **Atmospheric perspective** — distant things are lighter, cooler, lower
  contrast.
- **Framing** — use foreground elements (arches, branches, doorways) to ring the
  subject and add depth.

## Gestalt applied to layout

People perceive organized wholes. Use these to imply structure with less ink, and
re-scan afterward to catch *unintended* groupings:

- **Proximity** — group related items by closeness; separate groups with space.
- **Similarity** — shared color/shape/size signals "same kind."
- **Continuity** — aligned items read as connected; the eye follows lines/curves.
- **Closure** — the mind completes implied shapes (logos exploit this).
- **Figure/ground** — ensure the intended subject wins against the background.
- **Common region** — a shared container/background groups items (cards, panels).

## Quick layout recipe

1. Define the 1-2-3 hierarchy and the single message.
2. Pick balance type (sym/asym/radial) from the brand's doctrine.
3. Lay a grid + spacing scale; place the focal point on a thirds/golden point.
4. Group with proximity; align everything to shared lines.
5. Add generous negative space; reserve one accent for the focal element.
6. Trace the intended eye path (Z/F); confirm with the squint test.
