# Domains — fundamentals applied per medium

The grammar (composition, color, type, Gestalt) is universal; each medium bends
it. Read the relevant section in Compose/Tune and combine it with the Profile and
the core references. Each section: what changes, the medium's defaults, and its
classic gotchas.

## UI / Web

What changes: it's interactive, multi-state, multi-size, and read in an F-pattern.
Hierarchy must survive scrolling and resizing.

- **Grid & spacing**: 12-col responsive; an 8px (or 4px) spacing base; consistent
  component padding. Define breakpoints; design mobile-first.
- **Type**: body ≥16px, line length capped (~60-75ch) via max-width on text
  containers; clear scale for H1→caption.
- **Color**: 60-30-10 with mostly-neutral surfaces; accent reserved for primary
  actions; full **state** set (default/hover/active/focus/disabled) and **semantic**
  colors; visible focus rings; meet contrast on text *and* UI controls (3:1).
- **Layout**: one primary action per screen/section; group with cards/regions
  (Gestalt common region); align labels and fields; generous tap targets (≥44px).
- **Gotchas**: low-contrast "aesthetic" gray text; too many competing CTAs;
  inconsistent spacing; centered long text; ignoring empty/loading/error states;
  decoration over scannability.

## AI images (hand-off to `banana`)

What changes: you direct a generator instead of placing pixels; control comes
from the prompt + the Profile's imagery rules.

- Pull the Profile's **imagery direction**: medium, treatment (grade, light,
  mood), subject do/don't, recurring prompt anchors + negative anchors.
- Specify **composition** in the prompt: shot type, focal subject placement
  (rule of thirds), depth (fore/mid/background), lighting direction, color
  palette, lens/mood, aspect ratio.
- Keep text OUT of generated images when possible; overlay real type afterward
  for crisp, on-brand typography and control.
- **Gotchas**: palette drift from the brand; generic "stock" look; HDR/over-
  saturation; baked-in garbled text; inconsistent style across a set (fix with
  shared anchors + seed/style continuity).

## Advertising / social

What changes: glance media — you get ~1-3 seconds; one idea must land instantly.
(For full campaign strategy and copy, hand to `ad-alchemist`; Prism owns the
visual craft and on-brand look.)

- **One message, one focal point.** Brutal hierarchy: the hook/visual dominates;
  everything else is support.
- **Format-native sizing**: IG feed 4:5 (1080×1350), story/reel 9:16 (1080×1920),
  square 1:1, plus safe zones (keep text clear of UI overlays and edges).
- **Thumb-stop contrast**: high contrast and a clear subject survive a small,
  fast scroll; pass the squint test at thumbnail size.
- **Type**: large, legible at small sizes; minimal words; readable on the busiest
  frame (use a scrim/overlay behind text on photos).
- **Gotchas**: too much copy; logo/CTA too big or too early; text in unsafe zones;
  low contrast at small scale; off-brand palette for "performance."

## Posters / flyers / print

What changes: fixed, often viewed from distance and for seconds; physical specs
matter.

- **Distance hierarchy**: the headline/visual must read from across a room; one
  dominant element, dramatic scale jump to secondary info.
- **Z-pattern** flow for sparse layouts; reserve a clear path to the key info
  (what/when/where/CTA).
- **Print specs**: CMYK color (expect duller than screen RGB — proof it), 300dpi
  images, **bleed** (~3mm) + safe margins, embed/outline fonts. Pure `#000` vs.
  rich black for large fills.
- **Gotchas**: screen-bright colors that die in CMYK; low-res images; text in the
  trim zone; cramming every detail at equal size; no focal point.

## Logos & branding

What changes: must work tiny and huge, in one color, on any background, forever.

- **Simplicity & memorability**: reduce to the essential idea; the simplest form
  that's distinctive. Test at 16px and in pure black.
- **Scalability & versatility**: provide full-color, one-color, and reversed
  (knockout) versions; define clear space and minimum size.
- **Gestalt**: closure and figure/ground are the workhorses of clever marks.
- **Type-based marks**: kerning and proportion are everything; a wordmark is
  typography under a microscope.
- **Gotchas**: too detailed to scale; trend-chasing (dates fast); relies on color
  to be recognizable; no clear-space/usage rules → inconsistent application.

## Painting / illustration / fine composition

What changes: full authorial control of every element; composition and value are
paramount; no UI constraints.

- **Value structure first** — establish a strong light/dark pattern (a 3-5 value
  notan); a piece that fails in grayscale fails in color.
- **Focal point** via the eye's preferences: highest contrast, sharpest edges,
  most saturated color, and convergence of lines land at the subject; soften and
  mute the periphery.
- **Composition**: rule of thirds / golden spiral for placement; leading lines and
  gaze; foreground/midground/background for depth; framing; atmospheric
  perspective; deliberate edges (hard edges advance/focus, soft edges recede).
- **Color**: limited palette + temperature control; a dominant temperature with a
  complementary accent at the focal point.
- **Gotchas**: subject dead-center by accident; equal-weight elements competing
  ("tangents" and twins); even detail/contrast everywhere (no focus); value range
  too narrow.

## Slide decks / presentations

What changes: sequential, projected, read while someone talks — low information
density per slide.

- **One idea per slide**; large type (readable from the back row, ≥24-28pt body);
  high contrast for projection.
- **Consistent master**: fixed grid, type scale, color roles across all slides
  (repetition = professional).
- **Visuals over bullets**: a chart or image with a one-line takeaway beats a wall
  of text; if bulleted, few words per line.
- **Gotchas**: tiny text, dense bullets, inconsistent layouts slide-to-slide,
  low-contrast on projector, decorative templates that fight the content.
