# Movimiento

Una marca se reconoce también por **cómo se mueve**. El movimiento sale de la
esencia y del estilo (el barroco se enciman capas con drama; lo escandinavo
respira lento; el brutalismo corta seco; el Swiss se desliza con precisión).

## Firma de movimiento (va en el Brand Profile)

- **Carácter:** lento y suave · preciso · seco · elástico · orgánico e irregular.
- **Curvas y tiempos:** easing concreto (p. ej. `cubic-bezier(.22,1,.36,1)`), duraciones por tipo (micro 150-250 ms, entrada 500-900 ms, cambio de escena 1-1.6 s).
- **Gesto de revelación:** cómo aparece todo (se dibuja, se enfoca desde desenfoque, se escribe, corte seco, se pinta).
- **Transición entre escenas:** fundido con desenfoque, barrido, corte, el elemento viajero que se transforma.
- **Sonido** (video): si hay un tono o textura sonora propia.

## Mecánicas de página (elegir con propósito)

**A · Secciones con transiciones de estado** (por defecto)
El scroll es nativo. Al entrar a una sección se dispara una transición completa;
al volver, se revierte. Robusta en celular, siempre se ve entera aunque se baje
rápido, ligera.

**B · Animación atada al scroll**
Avanza con el dedo, cuadro a cuadro. Control de cine, pero delicada en celular
(barra del navegador, inercia) y se salta si se baja rápido. Usarla solo en 1-2
momentos donde el control con el dedo *significa* algo.

**Híbrido recomendado:** A como base + B puntual.

## Capas (profundidad con propósito)

- **Fondo persistente:** una sola capa para toda la página que cambia de estado; da continuidad.
- **Viajeros:** elementos que pasan de una sección a otra, se transforman y sostienen el hilo de la historia.
- **Texto:** una idea en pantalla a la vez, con la entrada/salida de la firma de movimiento.
- Más capas (hasta ~10) solo si la profundidad **dice** algo (importancia, tiempo, distancia); lo cercano pesa más.

## Reglas para celular

- Todo se activa con scroll o toque; nada depende de hover.
- Animar solo `transform` y `opacity`; filtros pesados y blur grande con moderación.
- Probar a 375 px antes que en escritorio; usar `100svh` para escenas a pantalla completa.
- `prefers-reduced-motion`: versión con fundidos simples y el mismo contenido.
- El texto siempre es texto real (lectura, accesibilidad, buscadores).
