# Leer señales

Objetivo: deducir hacia dónde apunta la marca **antes** de que el usuario nombre
un estilo. Ninguna señal decide sola; lo que decide es la **combinación**.

## Qué mirar en cada señal

**Paleta**
- Saturación (apagada ↔ neón), contraste (suave ↔ duro), temperatura (cálida ↔ fría).
- Cuántos colores y cómo se reparten (uno dominante + acento ↔ muchos iguales).
- Origen: ¿colores de la naturaleza, de pantalla, de imprenta, de metal, de época?

**Logo y tipografía**
- Geometría (circular, angular, orgánica, a mano), peso, contraste de trazo.
- Serif / sans / mono / display / manuscrita; ¿condensada, expandida?
- Ornamento o ausencia de él; ¿simetría?; ¿parece de qué década?

**Persona y voz**
- Cómo habla (formal, cercano, rudo, poético, técnico), qué defiende, contra qué va.
- Arquetipo y su sombra. La emoción única que la marca debe provocar.

**Contexto**
- Sector y lo que todos hacen en ese sector (para separarse, no para copiar).
- Precio, público (edad, cultura, estado interno), canal principal, lugar físico.
- Materiales reales del negocio (madera, acero, papel, código, tela, comida).

## De señales a hipótesis

1. Lista las señales en una línea cada una.
2. Por cada dirección candidata, anota cuáles señales la **sostienen** y cuáles la **contradicen**.
3. Descarta la que dependa de una sola señal.
4. Si dos señales fuertes chocan, formula la **tensión** como dirección posible.
5. Escribe cada hipótesis como razonamiento corto, p. ej.:
   > Neón + logo redondeado + público de 20 años + voz juguetona → **Y2K** antes que cyberpunk (cyberpunk pediría un logo angular y una voz distópica).

## Contrastes frecuentes (para no confundir estilos vecinos)

| Parecen iguales | Los separa |
|---|---|
| cyberpunk / Y2K / vaporwave / Miami Vice | distopía y dureza · optimismo digital plástico · nostalgia irónica · glamour de los 80 con sol |
| brutalismo web / neobrutalismo / Swiss | crudo y anti-estético · crudo pero amable con sombras duras y color · orden, retícula y claridad |
| minimalismo / escandinavo / japandi / wabi-sabi | reducción fría · calidez funcional y luz · calma natural oriental + función nórdica · belleza de lo imperfecto y lo gastado |
| art déco / Hollywood Regency / lujo silencioso | geometría escalonada y optimismo de máquina · glamour teatral · riqueza que no se anuncia |
| rústico / artesanal / industrial | materia natural y tiempo · la mano y el oficio · lo expuesto y funcional |

Si la marca queda entre dos, eso también es información: propón la mezcla.
