# Typography

Type is most of the content in most designs, so its craft is most of the
perceived quality. Two jobs: a clear **hierarchy** and effortless **readability**.

## Hierarchy first

Readers should grasp the structure — what's a title, a subhead, body, a caption —
before reading a word. Build distinct, obvious levels using:

- **Size** — the primary signal. Use clear jumps between levels (see scale).
- **Weight** — bold for emphasis and headings; don't fake it by stretching.
- **Color / value** — a darker or accent heading, lighter captions/meta.
- **Case & style** — small caps, italics, or all-caps (sparingly) to mark roles.
- **Space** — space around a heading signals importance as much as size does.

If three levels look almost the same size, the hierarchy is broken — widen the
steps.

## Type scale (size system)

Don't pick sizes ad hoc. Use a **modular scale**: a base size × a ratio.

- Common base: **16px** for screen body (the comfortable default; never set body
  below ~14px on web). Print body ≈ 10-12pt.
- Common ratios: 1.200 (Minor Third, subtle), **1.250 (Major Third, versatile)**,
  1.333 (Perfect Fourth, punchy), 1.618 (Golden, dramatic editorial).
- Example at 16 base, 1.250: 12 · 14 · 16 · 20 · 25 · 31 · 39 · 49.
- Pick 4-6 steps and reuse them everywhere; consistency is the point.

## Spacing: leading, tracking, measure

- **Leading (line-height)** — body text ≈ **1.4-1.6×** the size (1.5 is a safe
  default). Large headings go tighter (1.0-1.25). Too tight = cramped; too loose =
  lines stop feeling related.
- **Measure (line length)** — **~50-75 characters** per line for body (≈45-75).
  Too long and the eye loses its place returning to the next line; too short and
  rhythm breaks. Control with max-width, not by guessing.
- **Tracking (letter-spacing)** — leave body alone. Tighten large display type
  slightly; add positive tracking to ALL-CAPS and small labels for legibility.
- **Kerning** — fix awkward pairs only in logos/large display; body is fine as-is.
- **Paragraph spacing** — separate paragraphs with space or indent, never both;
  space reads more modern.

## Pairing fonts

- **Two families is plenty** (a heading face + a body face); three is the
  ceiling. More than that fragments the identity.
- **Contrast, don't clash.** The classic reliable pairing is a **serif heading +
  sans body** (or vice versa) — enough difference to feel intentional. Pairing two
  similar sans fonts usually looks like a mistake, not a choice.
- A single well-chosen **superfamily** (with multiple weights/widths) can carry an
  entire design — often the safest, most cohesive route.
- Match the **mood** to the brand: geometric sans = modern/rational; humanist sans
  = friendly/approachable; old-style serif = trustworthy/traditional; transitional/
  didone serif = elegant/editorial; slab = sturdy/confident; script = personal (use
  only as accent, never body).
- Check **x-height and proportions** are compatible so sizes feel balanced when
  set together.

## Readability checklist

- Body ≥ ~16px screen / 10-12pt print, contrast ≥ 4.5:1.
- Line length 50-75 characters.
- Leading ~1.5 for body.
- Left-aligned for long text (ragged right). Avoid justified on the web (rivers/
  uneven spacing) unless hyphenation is controlled. Center only short display
  lines; never center long paragraphs.
- Don't set long passages in all-caps, light weights on busy backgrounds, or pure
  gray below contrast targets.
- Limit emphasis: if everything is bold/colored, nothing is emphasized.

## Type as a design element

Beyond reading, type can *be* the composition: an oversized headline as the hero,
expressive display type, type on a grid as texture. When type is the focal point
(posters, brutalist layouts), scale and spacing decisions carry the whole design —
treat them with the same care as any image.

## Common type mistakes

- Too many fonts / fonts that don't contrast.
- Hierarchy steps too small to read as distinct.
- Body too small, lines too long, leading too tight.
- Centered or justified long body text.
- All-caps without added tracking.
- Light gray body text that fails contrast.
- Stretching/condensing letters to fake a weight or fit space.
